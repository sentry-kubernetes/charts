# Changelog


## 0.5.3 (2026-01-08)

* chore: update CHANGELOG.md for merged changes ([53c3b06](https://github.com/CloudPirates-io/helm-charts/commit/53c3b06))
* chore: auto-generate values.schema.json (#814) ([9920972](https://github.com/CloudPirates-io/helm-charts/commit/9920972))
* chore: update CHANGELOG.md for merged changes ([281856f](https://github.com/CloudPirates-io/helm-charts/commit/281856f))
* [nginx]: custom securityContext for initiContainers #765 ([dadbdb7](https://github.com/CloudPirates-io/helm-charts/commit/dadbdb7))

## 0.5.2 (2025-12-22)

* chore: update CHANGELOG.md for merged changes ([ddfd971](https://github.com/CloudPirates-io/helm-charts/commit/ddfd971))
* chore: update CHANGELOG.md for merged changes ([d48ff1b](https://github.com/CloudPirates-io/helm-charts/commit/d48ff1b))
* Update charts/nginx/values.yaml nginx (#746) ([d433040](https://github.com/CloudPirates-io/helm-charts/commit/d433040))

## 0.5.1 (2025-12-10)

* chore: update CHANGELOG.md for merged changes ([369bcaf](https://github.com/CloudPirates-io/helm-charts/commit/369bcaf))
* chore: update CHANGELOG.md for merged changes ([9e98116](https://github.com/CloudPirates-io/helm-charts/commit/9e98116))
* Update charts/nginx/values.yaml nginx to v1.29.4 (patch) (#718) ([48d2f15](https://github.com/CloudPirates-io/helm-charts/commit/48d2f15))
* chore: update CHANGELOG.md for merged changes ([0552f92](https://github.com/CloudPirates-io/helm-charts/commit/0552f92))
* chore: auto-generate values.schema.json (#665) ([ae1ac5a](https://github.com/CloudPirates-io/helm-charts/commit/ae1ac5a))

## 0.5.0 (2025-11-26)

* chore: update CHANGELOG.md for merged changes ([1050496](https://github.com/CloudPirates-io/helm-charts/commit/1050496))
* [nginx]: Configurable side car containers ([f525b11](https://github.com/CloudPirates-io/helm-charts/commit/f525b11))

## 0.4.3 (2025-11-16)

* chore: update CHANGELOG.md for merged changes ([5521d5f](https://github.com/CloudPirates-io/helm-charts/commit/5521d5f))
* chore: update CHANGELOG.md for merged changes ([f30dae3](https://github.com/CloudPirates-io/helm-charts/commit/f30dae3))
* [nginx]: feat: remove optional bitnami script sourcing (#601) ([9f6a837](https://github.com/CloudPirates-io/helm-charts/commit/9f6a837))
* chore: update CHANGELOG.md for merged changes ([96c472e](https://github.com/CloudPirates-io/helm-charts/commit/96c472e))
* chore: update CHANGELOG.md for merged changes ([9923048](https://github.com/CloudPirates-io/helm-charts/commit/9923048))

## 0.4.2 (2025-11-13)

* chore: update CHANGELOG.md for merged changes ([1c247b8](https://github.com/CloudPirates-io/helm-charts/commit/1c247b8))
* chore: update CHANGELOG.md for merged changes ([454ffde](https://github.com/CloudPirates-io/helm-charts/commit/454ffde))
* chore: auto-generate values.schema.json (#569) ([6790d09](https://github.com/CloudPirates-io/helm-charts/commit/6790d09))

## 0.4.1 (2025-11-07)

* [nginx]: Add podLabels ([b8d8410](https://github.com/CloudPirates-io/helm-charts/commit/b8d8410))
* chore: update CHANGELOG.md for merged changes ([40efff1](https://github.com/CloudPirates-io/helm-charts/commit/40efff1))
* chore: update CHANGELOG.md for merged changes ([e1c0077](https://github.com/CloudPirates-io/helm-charts/commit/e1c0077))
* chore: auto-generate values.schema.json (#549) ([ac12418](https://github.com/CloudPirates-io/helm-charts/commit/ac12418))
* chore: update CHANGELOG.md for merged changes ([05acd68](https://github.com/CloudPirates-io/helm-charts/commit/05acd68))
* chore: update CHANGELOG.md for merged changes ([d909109](https://github.com/CloudPirates-io/helm-charts/commit/d909109))

## 0.4.0 (2025-11-04)

* extraInitContainers (#548) ([686e3e0](https://github.com/CloudPirates-io/helm-charts/commit/686e3e0))
* chore: update CHANGELOG.md for merged changes ([8dbbdd1](https://github.com/CloudPirates-io/helm-charts/commit/8dbbdd1))
* chore: update CHANGELOG.md for merged changes ([5d68f20](https://github.com/CloudPirates-io/helm-charts/commit/5d68f20))
* chore: auto-generate values.schema.json (#529) ([a09c8b1](https://github.com/CloudPirates-io/helm-charts/commit/a09c8b1))
* chore: update CHANGELOG.md for merged changes ([b9cc0d3](https://github.com/CloudPirates-io/helm-charts/commit/b9cc0d3))
* chore: update CHANGELOG.md for merged changes ([8d930bc](https://github.com/CloudPirates-io/helm-charts/commit/8d930bc))

## 0.3.3 (2025-11-02)

* [nginx]: Add priorityClassName support (#526) ([e77747f](https://github.com/CloudPirates-io/helm-charts/commit/e77747f))

## 0.3.2 (2025-10-30)

* chore: update CHANGELOG.md for merged changes ([5c6a9eb](https://github.com/CloudPirates-io/helm-charts/commit/5c6a9eb))
* chore: update CHANGELOG.md for merged changes ([597f2b0](https://github.com/CloudPirates-io/helm-charts/commit/597f2b0))
* Update charts/nginx/values.yaml nginx (#508) ([60891a1](https://github.com/CloudPirates-io/helm-charts/commit/60891a1))
* chore: update CHANGELOG.md for merged changes ([28332c1](https://github.com/CloudPirates-io/helm-charts/commit/28332c1))
* chore: update CHANGELOG.md for merged changes ([16071aa](https://github.com/CloudPirates-io/helm-charts/commit/16071aa))

## 0.3.1 (2025-10-29)

* Update charts/nginx/values.yaml nginx to v1.29.3 (patch) (#490) ([a23c2db](https://github.com/CloudPirates-io/helm-charts/commit/a23c2db))
* chore: update CHANGELOG.md for merged changes ([8260788](https://github.com/CloudPirates-io/helm-charts/commit/8260788))
* chore: update CHANGELOG.md for merged changes ([402f7bd](https://github.com/CloudPirates-io/helm-charts/commit/402f7bd))

## 0.3.0 (2025-10-28)

* chore: auto-generate values.schema.json for updated charts (#455) ([aec6840](https://github.com/CloudPirates-io/helm-charts/commit/aec6840))
* chore: update CHANGELOG.md for merged changes ([f9c3ff0](https://github.com/CloudPirates-io/helm-charts/commit/f9c3ff0))
* chore: update CHANGELOG.md for merged changes ([db2d800](https://github.com/CloudPirates-io/helm-charts/commit/db2d800))

## 0.2.1 (2025-10-23)

* chore: update CHANGELOG.md for merged changes ([c80ea42](https://github.com/CloudPirates-io/helm-charts/commit/c80ea42))
* chore: update CHANGELOG.md for merged changes ([8ccb4bb](https://github.com/CloudPirates-io/helm-charts/commit/8ccb4bb))
* chore: update CHANGELOG.md for merged changes ([5d1f01a](https://github.com/CloudPirates-io/helm-charts/commit/5d1f01a))
* chore: update CHANGELOG.md for merged changes ([fc47c5d](https://github.com/CloudPirates-io/helm-charts/commit/fc47c5d))
* chore: update CHANGELOG.md for merged changes ([1a4f87b](https://github.com/CloudPirates-io/helm-charts/commit/1a4f87b))
* chore: update CHANGELOG.md for merged changes ([da866ca](https://github.com/CloudPirates-io/helm-charts/commit/da866ca))
* chore: update CHANGELOG.md for merged changes ([b54c4f1](https://github.com/CloudPirates-io/helm-charts/commit/b54c4f1))
* chore: update CHANGELOG.md for merged changes ([5a2ed20](https://github.com/CloudPirates-io/helm-charts/commit/5a2ed20))
* chore: update CHANGELOG.md for merged changes ([3361964](https://github.com/CloudPirates-io/helm-charts/commit/3361964))
* chore: update CHANGELOG.md for merged changes ([7f61172](https://github.com/CloudPirates-io/helm-charts/commit/7f61172))
* chore: update CHANGELOG.md for merged changes ([1ec9aab](https://github.com/CloudPirates-io/helm-charts/commit/1ec9aab))
* chore: update CHANGELOG.md for merged changes ([c9ff4ec](https://github.com/CloudPirates-io/helm-charts/commit/c9ff4ec))

## 0.2.0 (2025-10-14)

* chore: update CHANGELOG.md for merged changes ([86f1d25](https://github.com/CloudPirates-io/helm-charts/commit/86f1d25))
* Update chart.yaml dependencies for indepentent charts (#382) ([87acfb1](https://github.com/CloudPirates-io/helm-charts/commit/87acfb1))
* chore: update CHANGELOG.md for merged changes ([84cf67b](https://github.com/CloudPirates-io/helm-charts/commit/84cf67b))
* chore: update CHANGELOG.md for all charts via manual trigger ([6974964](https://github.com/CloudPirates-io/helm-charts/commit/6974964))
* Update charts/nginx/values.yaml nginx (#351) ([d73ca94](https://github.com/CloudPirates-io/helm-charts/commit/d73ca94))
* add tests for openshift (#226) ([c80c98a](https://github.com/CloudPirates-io/helm-charts/commit/c80c98a))

## 0.1.14 (2025-10-09)

* Update charts/nginx/values.yaml nginx to v1.29.2 (patch) (#263) ([b607e10](https://github.com/CloudPirates-io/helm-charts/commit/b607e10))

## 0.1.13 (2025-10-08)

* [nginx/nginx-prometheus-exporter] Update nginx/nginx-prometheus-exporter to v1.5 (#234) ([9f7f1e8](https://github.com/CloudPirates-io/helm-charts/commit/9f7f1e8))

## 0.1.12 (2025-10-07)

* Add prometheus nginx metrics exporter (#224) ([5bf615a](https://github.com/CloudPirates-io/helm-charts/commit/5bf615a))

## 0.1.11 (2025-10-01)

* update containerport documentation (#198) ([f20d6d4](https://github.com/CloudPirates-io/helm-charts/commit/f20d6d4))
* Changed README.md due to bug (wrong description) (#197) ([84fd116](https://github.com/CloudPirates-io/helm-charts/commit/84fd116))

## 0.1.10 (2025-09-30)

* Fix/nginx used ingress backend port (#190) ([096725e](https://github.com/CloudPirates-io/helm-charts/commit/096725e))

## 0.1.9 (2025-09-30)

* [Zookeeper] [Nginx] Change nginx and zookeeper security-context to use helper-function (#169) ([b581bc7](https://github.com/CloudPirates-io/helm-charts/commit/b581bc7))

## 0.1.8 (2025-09-26)


## 0.1.7 (2025-09-25)

* add predefined configmaps (#154) ([82c4bb6](https://github.com/CloudPirates-io/helm-charts/commit/82c4bb6))

## 0.1.6 (2025-09-11)

* Remove redundant single port configurations ([570075b](https://github.com/CloudPirates-io/helm-charts/commit/570075b))
* default disable cloneStaticSiteFromGit ([3913640](https://github.com/CloudPirates-io/helm-charts/commit/3913640))
* Fix multi port scenario ([29d3811](https://github.com/CloudPirates-io/helm-charts/commit/29d3811))
* Update CHANGELOG.md ([72f4eb9](https://github.com/CloudPirates-io/helm-charts/commit/72f4eb9))
* Bump chart version ([b322d47](https://github.com/CloudPirates-io/helm-charts/commit/b322d47))
* Implement fix ([7467d22](https://github.com/CloudPirates-io/helm-charts/commit/7467d22))

## 0.1.5 (2025-09-10)

* Update CHANGELOG.md ([84c70d6](https://github.com/CloudPirates-io/helm-charts/commit/84c70d6))
* Bump chart version ([3e4be77](https://github.com/CloudPirates-io/helm-charts/commit/3e4be77))
* Update CHANGELOG.md ([32fd09c](https://github.com/CloudPirates-io/helm-charts/commit/32fd09c))
* Implement static website git clone ([e081eab](https://github.com/CloudPirates-io/helm-charts/commit/e081eab))

## 0.1.4 (2025-09-10)

* Update CHANGELOG.md ([a337490](https://github.com/CloudPirates-io/helm-charts/commit/a337490))
* fix artifacthub-repo id ([e7a98fc](https://github.com/CloudPirates-io/helm-charts/commit/e7a98fc))

## 0.1.3 (2025-09-08)

* Update CHANGELOG.md ([d0f0153](https://github.com/CloudPirates-io/helm-charts/commit/d0f0153))
* Update appVersion ([933ba01](https://github.com/CloudPirates-io/helm-charts/commit/933ba01))
* Update CHANGELOG.md ([4ff2bbc](https://github.com/CloudPirates-io/helm-charts/commit/4ff2bbc))
* Bump nginx to latest version + alpine ([8b0fc57](https://github.com/CloudPirates-io/helm-charts/commit/8b0fc57))

## 0.1.2 (2025-09-08)

* update chart-icon ([7ed7c8e](https://github.com/CloudPirates-io/helm-charts/commit/7ed7c8e))
* Update CHANGELOG.md ([a13f40d](https://github.com/CloudPirates-io/helm-charts/commit/a13f40d))
* bump version to 0.1.2 ([f75a781](https://github.com/CloudPirates-io/helm-charts/commit/f75a781))
* fix containerport and change ingress host-pathtype ([60e3223](https://github.com/CloudPirates-io/helm-charts/commit/60e3223))

## 0.1.1 (2025-09-08)

* Update CHANGELOG.md ([19e5317](https://github.com/CloudPirates-io/helm-charts/commit/19e5317))
* add artifacthub-repo id ([ee4f192](https://github.com/CloudPirates-io/helm-charts/commit/ee4f192))

## 0.1.0 (2025-09-08)

* Initial tagged release
