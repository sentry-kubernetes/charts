# Changelog

## [34.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v34.0.0...sentry-v34.1.0) (2026-10-25)


### Features

* **charts/sentry/relay:** allow overriding resources for the configRender init container ([#2312](https://github.com/sentry-kubernetes/charts/issues/2312)) ([bff2535](https://github.com/sentry-kubernetes/charts/commit/bff25356e526506c3ab921de57435db72f249219))
* **sentry:** add support for customizing the init container image in the external Kafka provisioning job ([#2311](https://github.com/sentry-kubernetes/charts/issues/2311)) ([7d48b15](https://github.com/sentry-kubernetes/charts/commit/7d48b154d050eb461963c28b5c85ae802354643d))

## [34.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.8.0...sentry-v34.0.0) (2026-10-22)


### ⚠ BREAKING CHANGES

* upgrade to sentry v26.10.0 ([#2308](https://github.com/sentry-kubernetes/charts/issues/2308))

### Features

* upgrade to sentry v26.10.0 ([#2308](https://github.com/sentry-kubernetes/charts/issues/2308)) ([9c25207](https://github.com/sentry-kubernetes/charts/commit/9c252073c931e91aede5a4229c79734e13525eb2))


### Bug Fixes

* **charts/sentry:** change ConfigMap creation priority in taskbroker for first-time installation ([#2306](https://github.com/sentry-kubernetes/charts/issues/2306)) ([2a8c106](https://github.com/sentry-kubernetes/charts/commit/2a8c1063ef17f7b8adfb492080bf5330769e41db))

## [33.8.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.7.0...sentry-v33.8.0) (2026-08-24)


### Features

* **ci:** publish helm charts as OCI artifacts to GHCR ([#2292](https://github.com/sentry-kubernetes/charts/issues/2292)) ([339aae7](https://github.com/sentry-kubernetes/charts/commit/339aae7426ad1d23cf88ae367c7847e2d78bd4da))

## [33.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.6.0...sentry-v33.7.0) (2026-08-21)


### Features

* taskbroker postgresql store ([#2286](https://github.com/sentry-kubernetes/charts/issues/2286)) ([2f057a7](https://github.com/sentry-kubernetes/charts/commit/2f057a7bd90ad6d1534914fa4d5d9626d39f9d33))

## [33.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.5.0...sentry-v33.6.0) (2026-08-20)


### Features

* charts/sentry: source S3 and integration credentials from a Secret ([#2279](https://github.com/sentry-kubernetes/charts/issues/2279)) ([87bb399](https://github.com/sentry-kubernetes/charts/commit/87bb399c31f7f6e5b8c9bf14505e88dea01c520a))

## [33.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.4.0...sentry-v33.5.0) (2026-08-19)


### Features

* charts/sentry: add existingSecret support for GeoIP credentials ([#2284](https://github.com/sentry-kubernetes/charts/issues/2284)) ([b9d3d6d](https://github.com/sentry-kubernetes/charts/commit/b9d3d6d4b4e231b0c3ce4b0406820e00cf69b4fa))

## [33.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.3.1...sentry-v33.4.0) (2026-08-18)


### Features

* upgrade to sentry v26.8.0 ([#2281](https://github.com/sentry-kubernetes/charts/issues/2281)) ([86be27f](https://github.com/sentry-kubernetes/charts/commit/86be27faee920e0e662e17926301adc22b02c501))

## [33.3.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.3.0...sentry-v33.3.1) (2026-08-18)


### Bug Fixes

* **sentry:** update clickhouse cleanup cronjob template ([#2270](https://github.com/sentry-kubernetes/charts/issues/2270)) ([74e9fc8](https://github.com/sentry-kubernetes/charts/commit/74e9fc861eeb3f63a38140bfb061a3b486c3f25d))

## [33.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.2.0...sentry-v33.3.0) (2026-08-10)


### Features

* upgrade to v26.7.2 ([#2276](https://github.com/sentry-kubernetes/charts/issues/2276)) ([4fc47a7](https://github.com/sentry-kubernetes/charts/commit/4fc47a780d22ca5e73f544298e1d85ff8cd6918c))


### Bug Fixes

* charts/sentry: support TLS in ClickHouse cleanup ([#2274](https://github.com/sentry-kubernetes/charts/issues/2274)) ([58ec7f9](https://github.com/sentry-kubernetes/charts/commit/58ec7f9b5d5318afd740a69d9441fdb7a7c1e9a4))

## [33.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.1.0...sentry-v33.2.0) (2026-07-31)


### Features

* charts/sentry: add maxPollIntervalMs for snuba replacer ([#2266](https://github.com/sentry-kubernetes/charts/issues/2266)) ([52c48ca](https://github.com/sentry-kubernetes/charts/commit/52c48cae85bd150b04e89ca6517e1147e9e55aef))


### Bug Fixes

* charts/sentry: add missing taskworker topics to default provisioning list ([#2267](https://github.com/sentry-kubernetes/charts/issues/2267)) ([7c5113e](https://github.com/sentry-kubernetes/charts/commit/7c5113e77f0559b82d4b19e1470ae74625e8a59e))
* extend Recreate/RollingUpdate strategy to remaining Kafka consumer deployments ([#2238](https://github.com/sentry-kubernetes/charts/issues/2238)) ([#2269](https://github.com/sentry-kubernetes/charts/issues/2269)) ([e37c168](https://github.com/sentry-kubernetes/charts/commit/e37c168c55051a480a0a13df906a8db8863f4fa3))

## [33.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v33.0.0...sentry-v33.1.0) (2026-07-26)


### Features

* upgrade sentry to v26.7.1 ([#2263](https://github.com/sentry-kubernetes/charts/issues/2263)) ([d02cfb5](https://github.com/sentry-kubernetes/charts/commit/d02cfb51bac385935082a0cc458cbe83bca8fd02))


### Bug Fixes

* use Recreate strategy for single-partition Kafka consumers ([#2258](https://github.com/sentry-kubernetes/charts/issues/2258)) ([c261d9f](https://github.com/sentry-kubernetes/charts/commit/c261d9fe5d6d12279a49a863b4e5265d387a2cae))

## [33.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v32.3.0...sentry-v33.0.0) (2026-07-23)


### ⚠ BREAKING CHANGES

* upgrade sentry to v26.7.0 ([#2257](https://github.com/sentry-kubernetes/charts/issues/2257))

### Features

* charts/sentry: add maxPollIntervalMs for snuba eapItemsConsumer ([#2259](https://github.com/sentry-kubernetes/charts/issues/2259)) ([bdbbb72](https://github.com/sentry-kubernetes/charts/commit/bdbbb729cd3c1a2d8772605727c1a2b812ca5c72))
* upgrade sentry to v26.7.0 ([#2257](https://github.com/sentry-kubernetes/charts/issues/2257)) ([4743524](https://github.com/sentry-kubernetes/charts/commit/47435240145991bf7c4d85df554c875cdad9619c))

## [32.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v32.2.0...sentry-v32.3.0) (2026-07-13)


### Features

* charts/sentry: add configurable PagerDuty integration ([#2252](https://github.com/sentry-kubernetes/charts/issues/2252)) ([45ef34b](https://github.com/sentry-kubernetes/charts/commit/45ef34ba393bf371281402df38e6e335ac64766b))


### Bug Fixes

* add relay.asHook for rolling updates ([#2256](https://github.com/sentry-kubernetes/charts/issues/2256)) ([4f027e7](https://github.com/sentry-kubernetes/charts/commit/4f027e761ebf7b714d5b23bd63625a2310c36ef3))
* charts/sentry: render volumeMounts key for global.volumeMounts ([#2253](https://github.com/sentry-kubernetes/charts/issues/2253)) ([6338bc7](https://github.com/sentry-kubernetes/charts/commit/6338bc71339a5273ed2caf5031023066eda8bfd4))
* make relay config-render initContainer image configurable ([#2242](https://github.com/sentry-kubernetes/charts/issues/2242)) ([#2255](https://github.com/sentry-kubernetes/charts/issues/2255)) ([855caa6](https://github.com/sentry-kubernetes/charts/commit/855caa64766a309813c8501fe40eec2ce273166d))
* make S3 access_key/secret_key conditional for IRSA/Pod Identity support ([#2062](https://github.com/sentry-kubernetes/charts/issues/2062)) ([dcae06f](https://github.com/sentry-kubernetes/charts/commit/dcae06f0859486cdd65a5ad3c6502adb9484ee4d))

## [32.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v32.1.0...sentry-v32.2.0) (2026-06-11)


### Features

* charts/sentry: route: Add support for HTTPRoute timeouts ([#2231](https://github.com/sentry-kubernetes/charts/issues/2231)) ([7c713cc](https://github.com/sentry-kubernetes/charts/commit/7c713cc306aacf9c313d599261a34543f7bb9d84))

## [32.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v32.0.0...sentry-v32.1.0) (2026-06-09)


### Features

* add startup probe for kafka consumer workloads; tighten liveness timing ([#2233](https://github.com/sentry-kubernetes/charts/issues/2233)) ([9e4d85c](https://github.com/sentry-kubernetes/charts/commit/9e4d85cc00ff91dedf582012021c2feb5978e34f))


### Bug Fixes

* crash on sentry 26.5.2 due to snuba 26.5.2 ([#2236](https://github.com/sentry-kubernetes/charts/issues/2236)) ([dab6caf](https://github.com/sentry-kubernetes/charts/commit/dab6caf55be9561aae1b3811d423f57df7678524))

## [32.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.7.1...sentry-v32.0.0) (2026-06-04)


### ⚠ BREAKING CHANGES

* replace deprecated distutils.strtobool and enable rustConsumer ([#2227](https://github.com/sentry-kubernetes/charts/issues/2227))

### Features

* make setup-hook Job restartPolicy configurable ([#2232](https://github.com/sentry-kubernetes/charts/issues/2232)) ([bbb167e](https://github.com/sentry-kubernetes/charts/commit/bbb167e274376a7ad81a29df090d2a2eccbbde48))
* per taskbroker & taskworker topologySpreadConstraints ([#2228](https://github.com/sentry-kubernetes/charts/issues/2228)) ([546c7b7](https://github.com/sentry-kubernetes/charts/commit/546c7b76735f5c608371f3488f6d38fe4ebc3106))
* replace deprecated distutils.strtobool and enable rustConsumer ([#2227](https://github.com/sentry-kubernetes/charts/issues/2227)) ([21fa745](https://github.com/sentry-kubernetes/charts/commit/21fa745ca800dc2fd9e91fdcc46447fcf2d361ee))


### Bug Fixes

* mtime livenessprobe ([#2230](https://github.com/sentry-kubernetes/charts/issues/2230)) ([d7de9de](https://github.com/sentry-kubernetes/charts/commit/d7de9de267caa0977e5a45c96162d978b8eab825))

## [31.7.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.7.0...sentry-v31.7.1) (2026-05-30)


### Bug Fixes

* add hook-weight 3 to taskbroker and taskworker to prevent CrashLoopBackOff ([#2225](https://github.com/sentry-kubernetes/charts/issues/2225)) ([36afab2](https://github.com/sentry-kubernetes/charts/commit/36afab27227efc1b38cba85e22f97fd836e79605))
* auto-generate launchpad RPC shared secret on install and upgrade ([#2224](https://github.com/sentry-kubernetes/charts/issues/2224)) ([ef7a2e4](https://github.com/sentry-kubernetes/charts/commit/ef7a2e42b2d030aba0fbb1a040f23a2fa0e5544b))
* remove invalid annotations from hook jobs ([#2220](https://github.com/sentry-kubernetes/charts/issues/2220)) ([f128e76](https://github.com/sentry-kubernetes/charts/commit/f128e762126bc9597944beffce523fad5911d9b6))

## [31.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.6.0...sentry-v31.7.0) (2026-05-29)


### Features

* add TLS settings support for Kafka provisioning topicctl ([#2216](https://github.com/sentry-kubernetes/charts/issues/2216)) ([099d344](https://github.com/sentry-kubernetes/charts/commit/099d344892dcfe1cddc4680a07122f6d600a9016))
* configuration changes for sentry v26.5.0 ([#2212](https://github.com/sentry-kubernetes/charts/issues/2212)) ([3631380](https://github.com/sentry-kubernetes/charts/commit/36313806aeadec0737f155204c55bfa8b7f59729))
* enable cache (memcached) by default ([#2219](https://github.com/sentry-kubernetes/charts/issues/2219)) ([f451c66](https://github.com/sentry-kubernetes/charts/commit/f451c664e22d59185035317811b19685c7cd8866))


### Bug Fixes

* symbolicator cleaner sidecar ignores resource definitions ([#2218](https://github.com/sentry-kubernetes/charts/issues/2218)) ([ddc607b](https://github.com/sentry-kubernetes/charts/commit/ddc607b870d494818b345f76aa5f0f7ecb24e0db))

## [31.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.5.1...sentry-v31.6.0) (2026-05-26)


### Features

* replace netcat image with busybox for dbCheck hooks ([#2208](https://github.com/sentry-kubernetes/charts/issues/2208)) ([f07bcdc](https://github.com/sentry-kubernetes/charts/commit/f07bcdc150b4ff8392f3a9a07101bc233c913c11))


### Bug Fixes

* add missing annotations defaults to values.yaml for all components ([#2211](https://github.com/sentry-kubernetes/charts/issues/2211)) ([186e77a](https://github.com/sentry-kubernetes/charts/commit/186e77aa814cfc6436df6c313793215979aab3f0))
* use hooks.snubaMigrate instead of hooks.snubaInit in snuba-migrate job ([#2210](https://github.com/sentry-kubernetes/charts/issues/2210)) ([01ae3d6](https://github.com/sentry-kubernetes/charts/commit/01ae3d6850e8acefd359757b07c8f8560d651875))

## [31.5.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.5.0...sentry-v31.5.1) (2026-05-24)


### Bug Fixes

* **cleanerfs:** fix indentation in cleanerfs configuration ([#2194](https://github.com/sentry-kubernetes/charts/issues/2194)) ([ac293e3](https://github.com/sentry-kubernetes/charts/commit/ac293e35249aa60329605a601f807ebf255547bb))
* correct ingestFeedback serviceAccount condition and remove obsolete snuba-replacer option ([#2195](https://github.com/sentry-kubernetes/charts/issues/2195)) ([682f2a0](https://github.com/sentry-kubernetes/charts/commit/682f2a0d48e22cf5bd9b3153bb333d289e854189))
* remove dead code prefix and fix incorrect comments in externalClickhouse ([#2197](https://github.com/sentry-kubernetes/charts/issues/2197)) ([6e3f8a1](https://github.com/sentry-kubernetes/charts/commit/6e3f8a1cae53c4441106d00e66b25102db86abd3))

## [31.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.4.0...sentry-v31.5.0) (2026-05-22)


### Features

* add concurrency, inputBlockSize, maxBatchSize, maxBatchTimeMs support for ingest-occurences consumer ([#2191](https://github.com/sentry-kubernetes/charts/issues/2191)) ([e14ff97](https://github.com/sentry-kubernetes/charts/commit/e14ff97433b47507ae57abb0a29d309c0851bfee))


### Bug Fixes

* add timeoutSeconds to exec livenessProbe in consumer deployments ([#2187](https://github.com/sentry-kubernetes/charts/issues/2187)) ([3e0cc34](https://github.com/sentry-kubernetes/charts/commit/3e0cc341dff8e5e05c52065bc89f670a5ac7c249))
* use reconnecting memcache backend ([#2189](https://github.com/sentry-kubernetes/charts/issues/2189)) ([021e279](https://github.com/sentry-kubernetes/charts/commit/021e2794d7d90f49329bfeac71711697a9d9915b))

## [31.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.3.1...sentry-v31.4.0) (2026-05-22)


### Features

* bump Sentry appVersion to 26.5.0 ([#2179](https://github.com/sentry-kubernetes/charts/issues/2179)) ([a02bba8](https://github.com/sentry-kubernetes/charts/commit/a02bba850d4f38f67b1e1a6874473def8fe8bf45))
* support local JS SDK Loader asset hosting ([#2183](https://github.com/sentry-kubernetes/charts/issues/2183)) ([2999e18](https://github.com/sentry-kubernetes/charts/commit/2999e18489dfa6028882525458133eaaa4c587b0))

## [31.3.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.3.0...sentry-v31.3.1) (2026-05-21)


### Bug Fixes

* increase hooks.activeDeadlineSeconds to 1200 ([#2176](https://github.com/sentry-kubernetes/charts/issues/2176)) ([65c7993](https://github.com/sentry-kubernetes/charts/commit/65c799322990bc1625c6f7c7b1f86a5a6eda52b8))
* set worker threads explicitly ([#2173](https://github.com/sentry-kubernetes/charts/issues/2173)) ([94a5ce5](https://github.com/sentry-kubernetes/charts/commit/94a5ce510d70add8073d4ecc9bedfb93b5609b1e))

## [31.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.2.0...sentry-v31.3.0) (2026-05-20)


### Features

* add minInsyncReplicas support for external Kafka topic provisioning ([#2172](https://github.com/sentry-kubernetes/charts/issues/2172)) ([c795a25](https://github.com/sentry-kubernetes/charts/commit/c795a25f11b0ba6fe0736bb436d32f61d006fb6f))


### Bug Fixes

* uncomment tolerations and fix type from {} to [] for snuba cleanup and cleanerfs ([#2170](https://github.com/sentry-kubernetes/charts/issues/2170)) ([c1b612f](https://github.com/sentry-kubernetes/charts/commit/c1b612f5ff7a58f9ddb17f808c48f21ddaa72d62))

## [31.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.1.0...sentry-v31.2.0) (2026-05-10)


### Features

* add concurrency, maxBatchSize, maxBatchTimeMs support for process-spans and process-segments consumers ([#2159](https://github.com/sentry-kubernetes/charts/issues/2159)) ([cbff2c9](https://github.com/sentry-kubernetes/charts/commit/cbff2c968ff0df8935102ccf45bedcc9ff409fcb))

## [31.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v31.0.0...sentry-v31.1.0) (2026-05-09)


### Features

* add topicOverrides support for per-topic partition and config customization in Kafka provisioning ([#2162](https://github.com/sentry-kubernetes/charts/issues/2162)) ([257ca80](https://github.com/sentry-kubernetes/charts/commit/257ca8035c9740445358f992dd17dab71f97191a))
* upgrade to v26.4.2 ([#2160](https://github.com/sentry-kubernetes/charts/issues/2160)) ([01014cc](https://github.com/sentry-kubernetes/charts/commit/01014cc2bbd413c809fc5bc42bed22e62bcb92ed))

## [31.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.4.0...sentry-v31.0.0) (2026-05-06)


> [!CAUTION]
> This release has issues with Snuba migration if you're upgrading from previous version,
> see [getsentry/self-hosted #4286](https://github.com/getsentry/self-hosted/issues/4286).
>
> Please skip this release and upgrade straight to `31.1.0` instead.
>
> This release is fine if you're doing a fresh install.


### ⚠ BREAKING CHANGES

* require admin password and remove insecure default ([#2151](https://github.com/sentry-kubernetes/charts/issues/2151))

### Features

* add support topicctl for external kafka ([#2157](https://github.com/sentry-kubernetes/charts/issues/2157)) ([9ae8784](https://github.com/sentry-kubernetes/charts/commit/9ae878467a6ab49367dd452e3ca15e8c2ea3aa08))
* **cache:** add cache.enabled flag, deprecate sourcemaps.enabled ([#2156](https://github.com/sentry-kubernetes/charts/issues/2156)) ([0dc0ff7](https://github.com/sentry-kubernetes/charts/commit/0dc0ff76f612617986eb6410607faf9f4cbe6561))


### Bug Fixes

* add missing -- separator before consumer CLI options to prevent pod crashloops ([#2149](https://github.com/sentry-kubernetes/charts/issues/2149)) ([579ab05](https://github.com/sentry-kubernetes/charts/commit/579ab05d435246803ec9d49af9e1a47cf9aa1fed))
* harden shell scripts with set -euo pipefail ([#2155](https://github.com/sentry-kubernetes/charts/issues/2155)) ([d34dd65](https://github.com/sentry-kubernetes/charts/commit/d34dd65d1dfd2394b65422bf84bc286acdfef433))
* require admin password and remove insecure default ([#2151](https://github.com/sentry-kubernetes/charts/issues/2151)) ([c14b1bf](https://github.com/sentry-kubernetes/charts/commit/c14b1bf3b875fa4cfd59d179d55086ffbc17aa68))

## [30.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.3.1...sentry-v30.4.0) (2026-05-03)


> [!CAUTION]
> This release has issues with Snuba migration if you're upgrading from previous version,
> see [getsentry/self-hosted #4286](https://github.com/getsentry/self-hosted/issues/4286).
>
> Please skip this release and upgrade straight to `31.1.0` instead.
>
> This release is fine if you're doing a fresh install.


### Features

* move external kafka provisioning scripts from inline args to ConfigMap to avoid ARG_MAX limit ([#2146](https://github.com/sentry-kubernetes/charts/issues/2146)) ([3251f90](https://github.com/sentry-kubernetes/charts/commit/3251f905d336285128527cea2f273655eb37c3bf))
* upgrade to v26.4.0 ([#2145](https://github.com/sentry-kubernetes/charts/issues/2145)) ([1f90f1f](https://github.com/sentry-kubernetes/charts/commit/1f90f1f9e14827a913036745ef0a294e1a3b15ee))

## [30.3.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.3.0...sentry-v30.3.1) (2026-05-01)


### Bug Fixes

* correctly capture sentry createuser exit code in user-create hook ([#2121](https://github.com/sentry-kubernetes/charts/issues/2121)) ([b69c654](https://github.com/sentry-kubernetes/charts/commit/b69c6547256eb3bf9767a629024358459408c34e))

## [30.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.2.0...sentry-v30.3.0) (2026-04-29)


### Features

* **taskbroker:** inject TASKBROKER_KAFKA_SASL_* env vars when using external Kafka ([#2088](https://github.com/sentry-kubernetes/charts/issues/2088)) ([#2138](https://github.com/sentry-kubernetes/charts/issues/2138)) ([c640fe9](https://github.com/sentry-kubernetes/charts/commit/c640fe9a7570dca398a596ee57eede344f75fdc8))


### Bug Fixes

* Fix the condition to create gateway resources ([#2104](https://github.com/sentry-kubernetes/charts/issues/2104)) ([ff4f284](https://github.com/sentry-kubernetes/charts/commit/ff4f284f0f252cb38f5b33200e5e444bd626485a))

## [30.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.1.0...sentry-v30.2.0) (2026-04-27)


### Features

* **taskworker:** add maxChildTaskCount value to limit child process memory growth ([#2126](https://github.com/sentry-kubernetes/charts/issues/2126)) ([0765bdf](https://github.com/sentry-kubernetes/charts/commit/0765bdf3d0f59577f2c7d75c96daa9a6acbf2393))


### Bug Fixes

* add topic scheduled-subscriptions-eap-items ([#2133](https://github.com/sentry-kubernetes/charts/issues/2133)) ([c8ef918](https://github.com/sentry-kubernetes/charts/commit/c8ef918aade2f47f770b87d6a5d59c0a1c477c4d))
* **taskworker:** extend liveness probe initial delay to prevent CrashLoopBackOff ([#2128](https://github.com/sentry-kubernetes/charts/issues/2128)) ([#2131](https://github.com/sentry-kubernetes/charts/issues/2131)) ([6730fe7](https://github.com/sentry-kubernetes/charts/commit/6730fe79c39acd8f5314670c505e81d92618ccd1))

## [30.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.0.1...sentry-v30.1.0) (2026-04-21)


### Features

* **symbolicator:** support existing PVC name ([#2124](https://github.com/sentry-kubernetes/charts/issues/2124)) ([2e5f449](https://github.com/sentry-kubernetes/charts/commit/2e5f449c7778a90b62085177b61d9b31a787a6d4))


### Bug Fixes

* **snuba:** emit JSON booleans for ClickHouse secure/verify ([#2123](https://github.com/sentry-kubernetes/charts/issues/2123)) ([68ad867](https://github.com/sentry-kubernetes/charts/commit/68ad86721c466bc21d77179a9dc949573fb7861e))

## [30.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v30.0.0...sentry-v30.0.1) (2026-04-13)


### Bug Fixes

* symbolicator defaults, to include specific user ([#2119](https://github.com/sentry-kubernetes/charts/issues/2119)) ([a64656f](https://github.com/sentry-kubernetes/charts/commit/a64656f590e551dcccca0c1fd43f855b350a9d86))

## [30.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.5.1...sentry-v30.0.0) (2026-04-11)


### ⚠ BREAKING CHANGES

* separate livenessProbe & readinessProbe ([#2102](https://github.com/sentry-kubernetes/charts/issues/2102))

### Features

* allow to skip nodestore install via init container ([#2109](https://github.com/sentry-kubernetes/charts/issues/2109)) ([2f6a80f](https://github.com/sentry-kubernetes/charts/commit/2f6a80f9703382cda82f74e7ae7add1ea1639efc))
* **kafka:** update existing topic partitions and configs during provisioning ([#2095](https://github.com/sentry-kubernetes/charts/issues/2095)) ([203d17e](https://github.com/sentry-kubernetes/charts/commit/203d17ed859e9f611d6ed95a1e0c826670176f38))
* per taskbroker & taskworker resources ([#2103](https://github.com/sentry-kubernetes/charts/issues/2103)) ([3aa20fe](https://github.com/sentry-kubernetes/charts/commit/3aa20fe3252cbc1eb7ecea12fb2a02c559a78a67))
* **sentry:** add HPA for ingest-occurrences consumer ([#2111](https://github.com/sentry-kubernetes/charts/issues/2111)) ([1319e0c](https://github.com/sentry-kubernetes/charts/commit/1319e0cfd903e77f5e5ff30b8361219a8067bf51))
* separate livenessProbe & readinessProbe ([#2102](https://github.com/sentry-kubernetes/charts/issues/2102)) ([ebf7b93](https://github.com/sentry-kubernetes/charts/commit/ebf7b93019489f0294a1335bc6023bb5e4ccd142))


### Bug Fixes

* ensure all workloads respect global nodeSelector, tolerations, sidecars, volumeMounts, and volumes ([#2096](https://github.com/sentry-kubernetes/charts/issues/2096)) ([3493b9d](https://github.com/sentry-kubernetes/charts/commit/3493b9dca5fca98d28f556fd35ec26f8a76dd726))
* volumeMounts on deployment-uptime-checker and db-check-job ([#2114](https://github.com/sentry-kubernetes/charts/issues/2114)) ([7500ba1](https://github.com/sentry-kubernetes/charts/commit/7500ba1454327cb188045d3952745353b8599f8a))

## [29.5.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.5.0...sentry-v29.5.1) (2026-03-19)


### Bug Fixes

* **kafka:** topic provisioning for external Kafka cluster ([#2070](https://github.com/sentry-kubernetes/charts/issues/2070)) ([191a010](https://github.com/sentry-kubernetes/charts/commit/191a01035fe6d2e716e117ce7c8ec75e3f0aec46))
* **relay:** escape sed special characters in SASL credential substitution ([#2089](https://github.com/sentry-kubernetes/charts/issues/2089)) ([845504d](https://github.com/sentry-kubernetes/charts/commit/845504d4c283ccc04025f8aa22a21e0db5d95958))

## [29.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.4.1...sentry-v29.5.0) (2026-03-16)


### Features

* add global volumeMounts support across chart workloads ([#2083](https://github.com/sentry-kubernetes/charts/issues/2083)) ([482041d](https://github.com/sentry-kubernetes/charts/commit/482041dbfc8431adbb7c1ab0f036477d81a62290))
* Add optional memory-based autoscaling to all HPA components ([#2071](https://github.com/sentry-kubernetes/charts/issues/2071)) ([3e10c57](https://github.com/sentry-kubernetes/charts/commit/3e10c570d076d17ff81b2ada47245c390b661635))
* **sentry:** add support for Kafka SASL credentials from secret ([#2068](https://github.com/sentry-kubernetes/charts/issues/2068)) ([e68e92f](https://github.com/sentry-kubernetes/charts/commit/e68e92f80d88269148a8b99a1c3875e0bb227de2))
* **statefulset:** add persistentVolumeClaimRetentionPolicy option ([#2063](https://github.com/sentry-kubernetes/charts/issues/2063)) ([11c11b8](https://github.com/sentry-kubernetes/charts/commit/11c11b8718323e690c944a210388a965cda29ce3))


### Bug Fixes

* correct swapped default args for taskScheduler replicas in Helm chart ([#2064](https://github.com/sentry-kubernetes/charts/issues/2064)) ([163048a](https://github.com/sentry-kubernetes/charts/commit/163048a1510e044e96b9f2ce4aa3109f718f9506))
* **relay:** add explicit RollingUpdate strategy to prevent connection drops during redeployment ([#2078](https://github.com/sentry-kubernetes/charts/issues/2078)) ([419b5eb](https://github.com/sentry-kubernetes/charts/commit/419b5eb56779487e2a48dff5490848d4a1164248))

## [29.4.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.4.0...sentry-v29.4.1) (2026-03-09)


### Bug Fixes

* incorrect component labels on uptime-results and snuba eap-items deployments ([#2072](https://github.com/sentry-kubernetes/charts/issues/2072)) ([143d812](https://github.com/sentry-kubernetes/charts/commit/143d812678826e3024e169d7e909cefbfaa4708e))
* **relay:** indent logging key to be a root key ([#2066](https://github.com/sentry-kubernetes/charts/issues/2066)) ([d357411](https://github.com/sentry-kubernetes/charts/commit/d357411434a19cc01a50f702a0a252e14ccebb9d))

## [29.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.3.0...sentry-v29.4.0) (2026-02-26)


### Features

* upgrade to v26.2.1 ([22ae555](https://github.com/sentry-kubernetes/charts/commit/22ae5555474653532f7030c22bfad23d65775674))


### Bug Fixes

* **nginx:** nginx config name must match in the configmap and in the subchart values  ([#2058](https://github.com/sentry-kubernetes/charts/issues/2058)) ([69b5f06](https://github.com/sentry-kubernetes/charts/commit/69b5f06c4cd5c5537dbc490cb5e7363bb6ca92ac))

## [29.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.2.0...sentry-v29.3.0) (2026-02-19)


### Features

* add configurable clusterDomain to global section in values.yaml ([#2048](https://github.com/sentry-kubernetes/charts/issues/2048)) ([9d9b36d](https://github.com/sentry-kubernetes/charts/commit/9d9b36de11636e38d2a461c66004630b3041726f))
* support gcs as profiles backend ([#2051](https://github.com/sentry-kubernetes/charts/issues/2051)) ([6edda3b](https://github.com/sentry-kubernetes/charts/commit/6edda3bf5cf27e52ae641253f4bd9c0301c3a9bf))
* upgrade to v26.2.0 ([#2053](https://github.com/sentry-kubernetes/charts/issues/2053)) ([2180e03](https://github.com/sentry-kubernetes/charts/commit/2180e0382f80a8720633adc6ae97693e0c29025f))


### Bug Fixes

* add missing dnsPolicy to deployments ([#2046](https://github.com/sentry-kubernetes/charts/issues/2046)) ([ea1e67a](https://github.com/sentry-kubernetes/charts/commit/ea1e67a5d826ed9efacbb1195e1ab70ff08d1a77))
* remove empty arguments ([#2052](https://github.com/sentry-kubernetes/charts/issues/2052)) ([1acfcad](https://github.com/sentry-kubernetes/charts/commit/1acfcadc8733374a31fbeab5ccad1fbde3e5bbed))
* **routing:** nil pointer error when using Gateway API without nginx ([#2047](https://github.com/sentry-kubernetes/charts/issues/2047)) ([5820fd1](https://github.com/sentry-kubernetes/charts/commit/5820fd19a72cf0e1ccbdb73b33db5ff8393e89c2))

## [29.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.1.0...sentry-v29.2.0) (2026-02-10)


### Features

* optional separate replay storage ([#2040](https://github.com/sentry-kubernetes/charts/issues/2040)) ([404c688](https://github.com/sentry-kubernetes/charts/commit/404c6884e9f16f290053350e153d114d4b59d6d5))

## [29.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v29.0.0...sentry-v29.1.0) (2026-02-06)


### Features

* **cronjob:** add filesystem cleanup cronjob for filesystem backend ([#2037](https://github.com/sentry-kubernetes/charts/issues/2037)) ([a7a1b78](https://github.com/sentry-kubernetes/charts/commit/a7a1b78b74a363b7a3a3273c3e3868f78377a0ed))


### Bug Fixes

* Fix taskbroker persistence enabled flag ([#2036](https://github.com/sentry-kubernetes/charts/issues/2036)) ([ed5c3b6](https://github.com/sentry-kubernetes/charts/commit/ed5c3b68d0a94962ec8fdbb6790836bdc1a57e99))
* **nginx:** nginx config name must match in the configmap and in the subchart values ([#2042](https://github.com/sentry-kubernetes/charts/issues/2042)) ([f1cc6fd](https://github.com/sentry-kubernetes/charts/commit/f1cc6fdf0f5747f115ed997271efdb6b71ec47e3))

## [29.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v28.1.0...sentry-v29.0.0) (2026-02-04)


### ⚠ BREAKING CHANGES

* replace nginx chart, refactor ingress, unify routing configurations ([#2012](https://github.com/sentry-kubernetes/charts/issues/2012))
* remove bundled clickhouse chart ([#2029](https://github.com/sentry-kubernetes/charts/issues/2029))
* replace bitnami/memcached with cloudpirates/memcached ([#2014](https://github.com/sentry-kubernetes/charts/issues/2014))

### Features

* align defaults to sentry self hosted repo ([#2031](https://github.com/sentry-kubernetes/charts/issues/2031)) ([86b4c7c](https://github.com/sentry-kubernetes/charts/commit/86b4c7c2f05d410df81ea67cf50578d335db2a25))
* replace bitnami/memcached with cloudpirates/memcached ([#2014](https://github.com/sentry-kubernetes/charts/issues/2014)) ([1092a3c](https://github.com/sentry-kubernetes/charts/commit/1092a3c982477d0eb2d5c827d393c95b30d28be7))
* replace nginx chart, refactor ingress, unify routing configurations ([#2012](https://github.com/sentry-kubernetes/charts/issues/2012)) ([c7748d5](https://github.com/sentry-kubernetes/charts/commit/c7748d5562f84a43525a7b1d17d538a806c95c5a))


### Bug Fixes

* Convert github-app.id to integer for Sentry 26.x compatibility ([#2022](https://github.com/sentry-kubernetes/charts/issues/2022)) ([0b9de28](https://github.com/sentry-kubernetes/charts/commit/0b9de28e344b6766a0deec9ff5ebc91ed7dc1d5c))
* relay rename topic events/attachments ([#2033](https://github.com/sentry-kubernetes/charts/issues/2033)) ([bc07c1c](https://github.com/sentry-kubernetes/charts/commit/bc07c1c1af507af3b2b91b936800c0fd03174202))
* relay rename topic snuba-spans -&gt; ingest-spans ([#2032](https://github.com/sentry-kubernetes/charts/issues/2032)) ([859ce4f](https://github.com/sentry-kubernetes/charts/commit/859ce4f9e90cf65e43e242e059269317eeee7551))
* relay topic mappings for items ([#2030](https://github.com/sentry-kubernetes/charts/issues/2030)) ([a98c78b](https://github.com/sentry-kubernetes/charts/commit/a98c78b534a849bdc078234ad93666805a2d7cb7))


### Miscellaneous Chores

* remove bundled clickhouse chart ([#2029](https://github.com/sentry-kubernetes/charts/issues/2029)) ([4334428](https://github.com/sentry-kubernetes/charts/commit/4334428cee22eef330baa5591d7ce37fc963afe8))

## [28.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v28.0.3...sentry-v28.1.0) (2026-01-28)


### Features

* add optional environment variables for nodestore init container ([#2019](https://github.com/sentry-kubernetes/charts/issues/2019)) ([b4dab3d](https://github.com/sentry-kubernetes/charts/commit/b4dab3dde3bffb999961947274e3cd3291e2e170))
* **gateway:** add gateway api httpRoute support ([#2016](https://github.com/sentry-kubernetes/charts/issues/2016)) ([1c9a2f9](https://github.com/sentry-kubernetes/charts/commit/1c9a2f9c8501a0a140b49d62525705e193afcece))
* update sentry to v26 ([#2015](https://github.com/sentry-kubernetes/charts/issues/2015)) ([22c44f0](https://github.com/sentry-kubernetes/charts/commit/22c44f0c84a054be818c7812427f17f8e829aa03))

## [28.0.3](https://github.com/sentry-kubernetes/charts/compare/sentry-v28.0.2...sentry-v28.0.3) (2026-01-15)


### Bug Fixes

* high uwsgi memory usage caused by uwsgi allocating memory based on ([#1974](https://github.com/sentry-kubernetes/charts/issues/1974)) ([a50c90c](https://github.com/sentry-kubernetes/charts/commit/a50c90c7f44b6647f74c12b000e961c5656029a0))
* optionally take app_id and app_name from secrets for Github ([#2009](https://github.com/sentry-kubernetes/charts/issues/2009)) ([b70306c](https://github.com/sentry-kubernetes/charts/commit/b70306ca35b96b5e6a13358ae8988255f49be045))

## [28.0.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v28.0.1...sentry-v28.0.2) (2026-01-12)


### Bug Fixes

* symbolicator statefulset cleaner configuration ([#2004](https://github.com/sentry-kubernetes/charts/issues/2004)) ([80b95a4](https://github.com/sentry-kubernetes/charts/commit/80b95a4f1c8407f803d1b790b84ff03417f6b885))

## [28.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v28.0.0...sentry-v28.0.1) (2026-01-09)


### Bug Fixes

* duplicated envs for taskworker & taskscheduler ([#1998](https://github.com/sentry-kubernetes/charts/issues/1998)) ([f48af58](https://github.com/sentry-kubernetes/charts/commit/f48af589a1a4b98005ecedc5bcbf705651e4e2cf))
* symbolicator cleanup command arguments on statefulset ([#1995](https://github.com/sentry-kubernetes/charts/issues/1995)) ([12e957a](https://github.com/sentry-kubernetes/charts/commit/12e957adc92eb0ba1751cff4f9ce9dc6b0794bab))

## [28.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.11.0...sentry-v28.0.0) (2026-01-08)


### ⚠ BREAKING CHANGES

* upgrade to v25.12.1 ([#1981](https://github.com/sentry-kubernetes/charts/issues/1981))

### Features

* upgrade to v25.12.1 ([#1981](https://github.com/sentry-kubernetes/charts/issues/1981)) ([709b8f7](https://github.com/sentry-kubernetes/charts/commit/709b8f715a007feb3e6f180106923eae31b0d86a))

## [27.11.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.10.0...sentry-v27.11.0) (2026-01-06)


### Features

* **ingress:** Add native Traefik IngressRoute support ([#1972](https://github.com/sentry-kubernetes/charts/issues/1972)) ([096bac6](https://github.com/sentry-kubernetes/charts/commit/096bac6c0992b70b92e2fdc0593c1128aaf5b818))
* sync feature flags with self-hosted configuration 25.9.0 ([#1985](https://github.com/sentry-kubernetes/charts/issues/1985)) ([4bf8840](https://github.com/sentry-kubernetes/charts/commit/4bf8840ce558ef9ab103c6fa6f2e0847c903a5fd))

## [27.10.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.9.0...sentry-v27.10.0) (2025-12-18)


### Features

* **sentry:** bump nginx to 22.3.9 ([#1978](https://github.com/sentry-kubernetes/charts/issues/1978)) ([c83e9dc](https://github.com/sentry-kubernetes/charts/commit/c83e9dccb985d71aa5a1e8c25437627dd1fe5350))

## [27.9.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.8.1...sentry-v27.9.0) (2025-12-15)


### Features

* **hook:** ArgoCd Compatible Annotations for hook ([#1977](https://github.com/sentry-kubernetes/charts/issues/1977)) ([45f9ae9](https://github.com/sentry-kubernetes/charts/commit/45f9ae9f4c98fb8f86866715ec9e07916e08fa2e))
* sessionAffinityConfig and sessionAffinity for pgbouncer service ([#1964](https://github.com/sentry-kubernetes/charts/issues/1964)) ([0af7560](https://github.com/sentry-kubernetes/charts/commit/0af7560d30e77c312674af2dae8b3605aa21e00a))

## [27.8.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.8.0...sentry-v27.8.1) (2025-12-09)


### Bug Fixes

* change followed consumer group from eap_spans_group to eap_items_group ([#1970](https://github.com/sentry-kubernetes/charts/issues/1970)) ([809d94a](https://github.com/sentry-kubernetes/charts/commit/809d94ad4a18369e2741f3bca38e2112fdc3f434))
* **sentry:** correct template syntax for customFeatures conditional ([#1968](https://github.com/sentry-kubernetes/charts/issues/1968)) ([b438ba9](https://github.com/sentry-kubernetes/charts/commit/b438ba9d03c7a3ad31983a2d13b1c480599a8c51))

## [27.8.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.7.0...sentry-v27.8.0) (2025-12-05)


### Features

* **Symbolicator:** Map storageClassName in symbolicator PVC ([#1958](https://github.com/sentry-kubernetes/charts/issues/1958)) ([144358a](https://github.com/sentry-kubernetes/charts/commit/144358ae41c133325a1f81b63c2bd695d707e1c9))


### Bug Fixes

* **sentry/sentry/helper:** Redis URL not set when using `externalRedis.existingSecret` or `redis.auth.existingSecret` ([#1871](https://github.com/sentry-kubernetes/charts/issues/1871)) ([7c7a943](https://github.com/sentry-kubernetes/charts/commit/7c7a9437f9eb0f23fceb67e06f1df7520f2c2d5a))

## [27.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.6.2...sentry-v27.7.0) (2025-11-22)


### Features

* **pgbouncer/deployment:** Pass (extra) env from values ([#1946](https://github.com/sentry-kubernetes/charts/issues/1946)) ([d07a58b](https://github.com/sentry-kubernetes/charts/commit/d07a58b0a428c5e3a20764ff114d146fc060fd4e))


### Bug Fixes

* add vroom PVC Helm hooks when enable profiling feature ([#1950](https://github.com/sentry-kubernetes/charts/issues/1950)) ([a10e3fe](https://github.com/sentry-kubernetes/charts/commit/a10e3fedd9060b4e276cc7b3854306d898b08437))

## [27.6.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.6.1...sentry-v27.6.2) (2025-11-15)


### Bug Fixes

* add migrations excludePatterns for clickHouse cleanup ([#1941](https://github.com/sentry-kubernetes/charts/issues/1941)) ([a634c32](https://github.com/sentry-kubernetes/charts/commit/a634c328f0d2e4b12f4df8477fe3028499e3da1e))
* update clickhouse to 4.1.1 ([#1940](https://github.com/sentry-kubernetes/charts/issues/1940)) ([0ab54d0](https://github.com/sentry-kubernetes/charts/commit/0ab54d08a9a4b9f8ba9f27790ac01c6836a2982d))

## [27.6.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.6.0...sentry-v27.6.1) (2025-11-11)


### Bug Fixes

* **values:** Add warnings to broken ClickHouse cleanup job ([#1933](https://github.com/sentry-kubernetes/charts/issues/1933)) ([84be55c](https://github.com/sentry-kubernetes/charts/commit/84be55c35b5eb1e0d8dc86bd64b6761eb4a811df))

## [27.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.5.0...sentry-v27.6.0) (2025-11-09)


### Features

* add missing Kubernetes pod configuration options ([#1926](https://github.com/sentry-kubernetes/charts/issues/1926)) ([7083a0e](https://github.com/sentry-kubernetes/charts/commit/7083a0ececa5bbb2a0ac868620ce2e46061d599d))
* bump appversion from 25.8.0 to 25.9.0 ([#1927](https://github.com/sentry-kubernetes/charts/issues/1927)) ([5a5d1a9](https://github.com/sentry-kubernetes/charts/commit/5a5d1a90a048743619e968e18ba1b5b80b601ade))

## [27.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.4.2...sentry-v27.5.0) (2025-10-26)


### Features

* change pgbouncer repository ([#1908](https://github.com/sentry-kubernetes/charts/issues/1908)) ([8101fb9](https://github.com/sentry-kubernetes/charts/commit/8101fb9d2260e0e98f5ceb4dced88c22c714347f))
* persistence improvements ([#1853](https://github.com/sentry-kubernetes/charts/issues/1853)) ([93e598a](https://github.com/sentry-kubernetes/charts/commit/93e598a8e1da5f4202804b260fb042dac4d96b7d))

## [27.4.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.4.1...sentry-v27.4.2) (2025-10-01)


### Bug Fixes

* use bitnamilegacy repo for metrics exporter ([#1903](https://github.com/sentry-kubernetes/charts/issues/1903)) ([bdca84a](https://github.com/sentry-kubernetes/charts/commit/bdca84a2def5a694e89f92cb414a2ab31a3af769))

## [27.4.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.4.0...sentry-v27.4.1) (2025-09-30)


### Bug Fixes

* **sentry-ingest-consumer-attachments:** max batch time ms cli param ([#1895](https://github.com/sentry-kubernetes/charts/issues/1895)) ([fb963b3](https://github.com/sentry-kubernetes/charts/commit/fb963b38c6eda10f5674e38a0c7644d3c5dcefcd))

## [27.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.3.3...sentry-v27.4.0) (2025-09-19)


### Features

* Enhance clickhouse cleanup job ([#1886](https://github.com/sentry-kubernetes/charts/issues/1886)) ([af06a25](https://github.com/sentry-kubernetes/charts/commit/af06a259dc0a4f0fe36ccf40cf73c7e27570a876))

## [27.3.3](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.3.2...sentry-v27.3.3) (2025-09-19)


### Bug Fixes

* Add missing topics for snuba-subscription-consumer-eap-items ([#1888](https://github.com/sentry-kubernetes/charts/issues/1888)) ([8bf1cec](https://github.com/sentry-kubernetes/charts/commit/8bf1cec03cf5cf3b06efc3327d35424486849bb4))

## [27.3.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.3.1...sentry-v27.3.2) (2025-09-18)


### Bug Fixes

* bitnamilegacy image for kafka jmx exporter ([#1884](https://github.com/sentry-kubernetes/charts/issues/1884)) ([6514662](https://github.com/sentry-kubernetes/charts/commit/65146629decbc69d7e62f978c2c3e2e0ade8a8b1))

## [27.3.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.3.0...sentry-v27.3.1) (2025-09-15)


### Bug Fixes

* cronjob Config ([#1881](https://github.com/sentry-kubernetes/charts/issues/1881)) ([b5673ef](https://github.com/sentry-kubernetes/charts/commit/b5673efddb96533e587194896ddcdb0d0dfeb048))

## [27.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.2.4...sentry-v27.3.0) (2025-09-15)


### Features

* **clickhouse:** db cleanup ([#1876](https://github.com/sentry-kubernetes/charts/issues/1876)) ([e2e911d](https://github.com/sentry-kubernetes/charts/commit/e2e911d6ac5c48fe4cd138469b07f215093d341b))

## [27.2.4](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.2.3...sentry-v27.2.4) (2025-09-07)


### Bug Fixes

* Update serviceaccount-sentry-uptime-results ([#1869](https://github.com/sentry-kubernetes/charts/issues/1869)) ([dbdb24a](https://github.com/sentry-kubernetes/charts/commit/dbdb24a3077a692eee456f5f83ae73ffe9dc14be))

## [27.2.3](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.2.2...sentry-v27.2.3) (2025-09-03)


### Bug Fixes

* [#1859](https://github.com/sentry-kubernetes/charts/issues/1859) & [#1863](https://github.com/sentry-kubernetes/charts/issues/1863) ([#1861](https://github.com/sentry-kubernetes/charts/issues/1861)) ([e0879f9](https://github.com/sentry-kubernetes/charts/commit/e0879f947eb3145c6a9874bc867ee872d5fbdd42))

## [27.2.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.2.1...sentry-v27.2.2) (2025-09-03)


### Bug Fixes

* **templates:** fix indentation for multiple deployments yamls ([#1862](https://github.com/sentry-kubernetes/charts/issues/1862)) ([9a10dfd](https://github.com/sentry-kubernetes/charts/commit/9a10dfdbca95aff0216b121d8c8b3f40a5b960d4))

## [27.2.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.2.0...sentry-v27.2.1) (2025-09-02)


### Bug Fixes

* snuba-subscription-consumer-generic-metrics-distribution labels indent ([#1858](https://github.com/sentry-kubernetes/charts/issues/1858)) ([43f595c](https://github.com/sentry-kubernetes/charts/commit/43f595c10de214dedb0fa11922af937106c5ab37))

## [27.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.1.1...sentry-v27.2.0) (2025-09-02)


### Features

* add recommended labels ([#1839](https://github.com/sentry-kubernetes/charts/issues/1839)) ([4ae9f92](https://github.com/sentry-kubernetes/charts/commit/4ae9f92e7d2da33d0860760efabd13dd00e4734e))
* **hpa:** add behavior support for hpa v2 ([#1855](https://github.com/sentry-kubernetes/charts/issues/1855)) ([f5b8f7b](https://github.com/sentry-kubernetes/charts/commit/f5b8f7b8bfb5e34bec02e3b3be132340a270bdbb))
* upgrade to 25.8.0 ([#1851](https://github.com/sentry-kubernetes/charts/issues/1851)) ([d3a3ed4](https://github.com/sentry-kubernetes/charts/commit/d3a3ed486c264d56f11e7fbf0023757e8914fdf4))


### Bug Fixes

* generic metric alerts ([#1850](https://github.com/sentry-kubernetes/charts/issues/1850)) ([b1ba5b3](https://github.com/sentry-kubernetes/charts/commit/b1ba5b35cadb718eb7d664ff23c39c91b19ecbc2))

## [27.1.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.1.0...sentry-v27.1.1) (2025-08-21)


### Bug Fixes

* **deps:** Use bitnami images from docker.io/bitnamilegacy due to bitnami deprecating their public catalog. See https://github.com/bitnami/charts/issues/35164 ([#1840](https://github.com/sentry-kubernetes/charts/issues/1840)) ([e47d24e](https://github.com/sentry-kubernetes/charts/commit/e47d24ed1607e0632e7e433a119b9d299b69d9cc))

## [27.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.0.1...sentry-v27.1.0) (2025-07-25)


### Features

* add params for consumers ([#1824](https://github.com/sentry-kubernetes/charts/issues/1824)) ([883d9ea](https://github.com/sentry-kubernetes/charts/commit/883d9ea6d7918128367d9c1e1554e8dbe1bfc03b))

## [27.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v27.0.0...sentry-v27.0.1) (2025-07-24)


### Bug Fixes

* **vroom:** add persistent storage configuration ([#1822](https://github.com/sentry-kubernetes/charts/issues/1822)) ([82d2c51](https://github.com/sentry-kubernetes/charts/commit/82d2c51228ab040d17586f170b2f37e682ea670c))

## [27.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.22.0...sentry-v27.0.0) (2025-07-23)


### ⚠ BREAKING CHANGES

* **deps:** update helm release clickhouse to v4 ([#1775](https://github.com/sentry-kubernetes/charts/issues/1775))

### Features

* **deps:** update helm release clickhouse to v4 ([#1775](https://github.com/sentry-kubernetes/charts/issues/1775)) ([4e86110](https://github.com/sentry-kubernetes/charts/commit/4e8611025be55045f948f951aa1b8869971f0419))
* **sentry:** upgrade version ([#1819](https://github.com/sentry-kubernetes/charts/issues/1819)) ([afe197c](https://github.com/sentry-kubernetes/charts/commit/afe197cc17021f5a8a38f75c0760058f3f828423))
* **snuba:** add deployment configuration for EAP items consumer ([#1818](https://github.com/sentry-kubernetes/charts/issues/1818)) ([a4e1749](https://github.com/sentry-kubernetes/charts/commit/a4e1749e6c3dd8deca9ffa113331b3a8eafc50b9))


### Bug Fixes

* support `containerSecurityContext` for Symbolicator Cleaner container ([#1817](https://github.com/sentry-kubernetes/charts/issues/1817)) ([517e2ae](https://github.com/sentry-kubernetes/charts/commit/517e2ae4d783a0927d743596763b30f24a344bb8))

## [26.22.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.21.0...sentry-v26.22.0) (2025-07-21)


### Features

* add distributed cluster name config ([#1780](https://github.com/sentry-kubernetes/charts/issues/1780)) ([1ce32ab](https://github.com/sentry-kubernetes/charts/commit/1ce32ab717ce022730021e629dbeb1d2dd30a5b3))
* add errors-only mode from original self-hosted compose ([#1810](https://github.com/sentry-kubernetes/charts/issues/1810)) ([3f29825](https://github.com/sentry-kubernetes/charts/commit/3f29825126050887312bc6a5828a4d34aa2aa444))


### Bug Fixes

* **sentry:** set `SENTRY_SELF_HOSTED_ERRORS_ONLY` when neeeded ([#1812](https://github.com/sentry-kubernetes/charts/issues/1812)) ([bccb3fb](https://github.com/sentry-kubernetes/charts/commit/bccb3fba295d1f375bf5263fb62a9c65279886d3))

## [26.21.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.20.1...sentry-v26.21.0) (2025-07-09)


### Features

* add maxPollIntervalMs to consumers ([#1805](https://github.com/sentry-kubernetes/charts/issues/1805)) ([267acc7](https://github.com/sentry-kubernetes/charts/commit/267acc7e6bd0313cada0fcce40dfa54f063ca24d))

## [26.20.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.20.0...sentry-v26.20.1) (2025-07-09)


### Bug Fixes

* **snuba:** update consumer group name for profiling chunks consumer ([#1803](https://github.com/sentry-kubernetes/charts/issues/1803)) ([d1fb89b](https://github.com/sentry-kubernetes/charts/commit/d1fb89b8a9038d9ed47ac592073dfda39c05e3b5))

## [26.20.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.19.0...sentry-v26.20.0) (2025-07-08)


### Features

* **snuba:** add deployment configuration for generic metrics gauges consumer ([#1800](https://github.com/sentry-kubernetes/charts/issues/1800)) ([3ae3580](https://github.com/sentry-kubernetes/charts/commit/3ae35804207f124e1d50d8271bd7f2eeabc137e7))
* **snuba:** add deployment profile chunks ([#1799](https://github.com/sentry-kubernetes/charts/issues/1799)) ([5addbf3](https://github.com/sentry-kubernetes/charts/commit/5addbf3ab7e134ba187c6fc9a9973fc3f01e3ea0))

## [26.19.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.18.0...sentry-v26.19.0) (2025-06-14)


### Features

* update sentry appVersion to v25.5.1 ([#1782](https://github.com/sentry-kubernetes/charts/issues/1782)) ([9e9a05f](https://github.com/sentry-kubernetes/charts/commit/9e9a05f1930bd3e58c4fa94eefc5dd78ca9c72e3))


### Bug Fixes

* clickhouse env. ([#1786](https://github.com/sentry-kubernetes/charts/issues/1786)) ([3f13f00](https://github.com/sentry-kubernetes/charts/commit/3f13f00882c339f65500c50a96272db41be5b365))

## [26.18.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.17.1...sentry-v26.18.0) (2025-05-21)


### Features

* add more values for sentry ([#1765](https://github.com/sentry-kubernetes/charts/issues/1765)) ([cdd0905](https://github.com/sentry-kubernetes/charts/commit/cdd0905581c01309caee734e9f778add0cf3cf4c))

## [26.17.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.17.0...sentry-v26.17.1) (2025-05-12)


### Bug Fixes

* fix typo in value of argument '--consumer-group' for ([#1758](https://github.com/sentry-kubernetes/charts/issues/1758)) ([15d1811](https://github.com/sentry-kubernetes/charts/commit/15d1811b088b26f20215970d53622e59d4973728))

## [26.17.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.16.0...sentry-v26.17.0) (2025-05-09)


### Features

* update sentry appVersion to v25.4.0 ([#1754](https://github.com/sentry-kubernetes/charts/issues/1754)) ([b34f26d](https://github.com/sentry-kubernetes/charts/commit/b34f26d95b29970152b33c45dbb9ee94fe3a5515))

## [26.16.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.15.1...sentry-v26.16.0) (2025-04-15)


### Features

* add clickhouse ssl config ([#1671](https://github.com/sentry-kubernetes/charts/issues/1671)) ([a48f91c](https://github.com/sentry-kubernetes/charts/commit/a48f91c8218cb9f9363c249a02407e776f5ced1c))
* update appVersion to 25.3.0 ([#1740](https://github.com/sentry-kubernetes/charts/issues/1740)) ([9ed13bb](https://github.com/sentry-kubernetes/charts/commit/9ed13bbd7b604681ee8079bb53d427376552a40a))

## [26.15.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.15.0...sentry-v26.15.1) (2025-03-06)


### Bug Fixes

* **nginx:** _assets should rewrite to _static/sentry/dist ([#1719](https://github.com/sentry-kubernetes/charts/issues/1719)) ([be4d8c5](https://github.com/sentry-kubernetes/charts/commit/be4d8c5619b4fe42e7c47c6f58ea8513e0cff284))

## [26.15.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.14.1...sentry-v26.15.0) (2025-03-03)


### Features

* add `imagePullSecrets` option to the metrics deployment ([#1722](https://github.com/sentry-kubernetes/charts/issues/1722)) ([3463781](https://github.com/sentry-kubernetes/charts/commit/3463781b9f1dcba2350e8d6bef9aa4dfc9e12083))
* update appVersion to 25.2.0 ([#1713](https://github.com/sentry-kubernetes/charts/issues/1713)) ([8c5fc21](https://github.com/sentry-kubernetes/charts/commit/8c5fc210556bd6b7f604709ccfc9aa30ea1cd0b8))

## [26.14.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.14.0...sentry-v26.14.1) (2025-02-14)


### Bug Fixes

* Add missing global sidecar to ingestConsumerTransactions deployment ([#1705](https://github.com/sentry-kubernetes/charts/issues/1705)) ([5a9f5d7](https://github.com/sentry-kubernetes/charts/commit/5a9f5d762dfa693374f598fd8eec9754cc17ad6c))

## [26.14.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.13.0...sentry-v26.14.0) (2025-01-31)


### Features

* Add monitorsClockTasks and monitorsClockTick ([#1690](https://github.com/sentry-kubernetes/charts/issues/1690)) ([1fe663d](https://github.com/sentry-kubernetes/charts/commit/1fe663d345c9e420c901f25dc306e0e27549d905))


### Bug Fixes

* set replication factor for kafka stability ([#1606](https://github.com/sentry-kubernetes/charts/issues/1606)) ([7ebb1f6](https://github.com/sentry-kubernetes/charts/commit/7ebb1f636984485dd646eb482978bde3a4f3da36))

## [26.13.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.12.1...sentry-v26.13.0) (2025-01-30)


### Features

* update appVersion to 25.1.0 and add topic ([#1686](https://github.com/sentry-kubernetes/charts/issues/1686)) ([31e7368](https://github.com/sentry-kubernetes/charts/commit/31e73689f25ef1ab4d17e6f41a16d91b62a4d475))

## [26.12.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.12.0...sentry-v26.12.1) (2025-01-28)


### Bug Fixes

* rollback to 24.12.1 ([aa6cad8](https://github.com/sentry-kubernetes/charts/commit/aa6cad88fe0f2e0594aff7325d33f3ed643f250a))

## [26.12.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.11.2...sentry-v26.12.0) (2025-01-26)


### Features

* add custom labels for ingress ([#1672](https://github.com/sentry-kubernetes/charts/issues/1672)) ([712a469](https://github.com/sentry-kubernetes/charts/commit/712a4696a2d163ee83baad61453e7a3fa2da4f3d))
* add Kafka topics from upstream projects (Sentry and Snuba) for version 24.12.2 ([#1678](https://github.com/sentry-kubernetes/charts/issues/1678)) ([cf696b7](https://github.com/sentry-kubernetes/charts/commit/cf696b75d1c13b9f1af3388c3d818b8fdffee71b))


### Bug Fixes

* missing block in ingest-consumer-transactions ([#1680](https://github.com/sentry-kubernetes/charts/issues/1680)) ([424f50f](https://github.com/sentry-kubernetes/charts/commit/424f50f7f4c5572b13c68659bb91bdaba50c3e1e))

## [26.11.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.11.1...sentry-v26.11.2) (2025-01-18)


### Bug Fixes

* update readme.md with latest configuration values ([#1666](https://github.com/sentry-kubernetes/charts/issues/1666)) ([070b19f](https://github.com/sentry-kubernetes/charts/commit/070b19f11c95bd294d9c5419ca5d7d17dfa092fa))

## [26.11.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.11.0...sentry-v26.11.1) (2025-01-17)


### Bug Fixes

* clickhouse-chart for correct placement of internal_replication ([#1662](https://github.com/sentry-kubernetes/charts/issues/1662)) ([a3e82be](https://github.com/sentry-kubernetes/charts/commit/a3e82be0f081e4e548658d7acecdcb761a57b469))
* global nodeSelector config option not applying to cleanup cron job ([#1654](https://github.com/sentry-kubernetes/charts/issues/1654)) ([4e764b5](https://github.com/sentry-kubernetes/charts/commit/4e764b5ab006682b609571ae0b9f06014103e194))

## [26.11.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.10.0...sentry-v26.11.0) (2025-01-13)


### Features

* Sentry 24.11.2 ([#1640](https://github.com/sentry-kubernetes/charts/issues/1640)) ([70d0710](https://github.com/sentry-kubernetes/charts/commit/70d0710d0f063d346eb0743ef2745ce40d57c764))

## [26.10.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.9.1...sentry-v26.10.0) (2025-01-03)


### Features

* update Sentry chart to appVersion 24.10.0 ([#1652](https://github.com/sentry-kubernetes/charts/issues/1652)) ([72f61ff](https://github.com/sentry-kubernetes/charts/commit/72f61ff7ae1a26d11865cec083861041d94e029d))

## [26.9.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.9.0...sentry-v26.9.1) (2024-12-23)


### Bug Fixes

* add Kafka topics from upstream projects (Sentry and Snuba) for version 24.9.0 ([#1647](https://github.com/sentry-kubernetes/charts/issues/1647)) ([cac64cf](https://github.com/sentry-kubernetes/charts/commit/cac64cff98fe9b11a29c83e5f562086ad5f4e00a))

## [26.9.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.8.1...sentry-v26.9.0) (2024-12-16)


### Features

* add variable for SAMPLED_DEFAULT_RATE ([#1634](https://github.com/sentry-kubernetes/charts/issues/1634)) ([7910f9d](https://github.com/sentry-kubernetes/charts/commit/7910f9d0030b9c09206e01762e284003d9e61639))

## [26.8.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.8.0...sentry-v26.8.1) (2024-12-11)


### Bug Fixes

* Add missing ingest for feedback events ([#1630](https://github.com/sentry-kubernetes/charts/issues/1630)) ([3882cae](https://github.com/sentry-kubernetes/charts/commit/3882cae9b5cde0591f87b9021e09ddbad27ca659))
* missing flags required for Queues and Queries instrumentation ([#1622](https://github.com/sentry-kubernetes/charts/issues/1622)) ([a9b6b61](https://github.com/sentry-kubernetes/charts/commit/a9b6b61c842c5a92f0e011d3ae74c489bb83602c))
* missing profilingFunctionsConsumer.sidecars ([#1627](https://github.com/sentry-kubernetes/charts/issues/1627)) ([bcbd6ed](https://github.com/sentry-kubernetes/charts/commit/bcbd6ed01e76d741ab500adf1aa6038f0b36f631))

## [26.8.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.7.0...sentry-v26.8.0) (2024-12-04)


### Features

* add configuration for noStrictOffsetReset ([#1620](https://github.com/sentry-kubernetes/charts/issues/1620)) ([234552e](https://github.com/sentry-kubernetes/charts/commit/234552e186a5b9ed814595ce83bc744034c93821))
* Add missing sidecar and global parameter for deployments & hooks ([#1230](https://github.com/sentry-kubernetes/charts/issues/1230)) ([ac8143f](https://github.com/sentry-kubernetes/charts/commit/ac8143fd1607c0493ea5c60940be3e649f6d613b))

## [26.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.6.0...sentry-v26.7.0) (2024-11-28)


### Features

* pgbouncer for postgresql ([#1607](https://github.com/sentry-kubernetes/charts/issues/1607)) ([07157bd](https://github.com/sentry-kubernetes/charts/commit/07157bd61bff026cd80d912d16c140c9168d90d3))

## [26.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.5.0...sentry-v26.6.0) (2024-11-25)


### Features

* disable Sentry anonymous usage statistics ([#1608](https://github.com/sentry-kubernetes/charts/issues/1608)) ([b679d97](https://github.com/sentry-kubernetes/charts/commit/b679d97e21e787857a7d1dc8fd7c84ceb759e083))

## [26.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.4.0...sentry-v26.5.0) (2024-11-05)


### Features

* recovery support multi hosts and ports of external kafka cluster ([#1588](https://github.com/sentry-kubernetes/charts/issues/1588)) ([889bd0d](https://github.com/sentry-kubernetes/charts/commit/889bd0d47235cb1ab5a7b52439f5b8df61026a03))

## [26.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.3.0...sentry-v26.4.0) (2024-11-03)


### Features

* add maxBatchTimeMs, maxPollIntervalMs for ingestConsumerAttachments ([#1591](https://github.com/sentry-kubernetes/charts/issues/1591)) ([72af218](https://github.com/sentry-kubernetes/charts/commit/72af2189d2249cc29de1442179ce2258da958e44))

## [26.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.2.0...sentry-v26.3.0) (2024-10-26)


### Features

* Introduce global tolerations across all components ([#1580](https://github.com/sentry-kubernetes/charts/issues/1580)) ([7b48399](https://github.com/sentry-kubernetes/charts/commit/7b48399efe73cbb582b4df34068d0104ae3d969c))

## [26.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.1.0...sentry-v26.2.0) (2024-10-25)


### Features

* allow users to specify Kafka topic name prefix in values.yaml ([#1544](https://github.com/sentry-kubernetes/charts/issues/1544)) ([5693406](https://github.com/sentry-kubernetes/charts/commit/569340626ce1587d48040a939b80ab74874fd022))
* **rabbitmq:** updated configuration to support Prometheus ([#1578](https://github.com/sentry-kubernetes/charts/issues/1578)) ([35f779a](https://github.com/sentry-kubernetes/charts/commit/35f779a0f18b2b9108470efc86403fa3c0eefae2))

## [26.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v26.0.0...sentry-v26.1.0) (2024-10-25)


### Features

* add global nodeSelector fallback for all deployments ([#1576](https://github.com/sentry-kubernetes/charts/issues/1576)) ([d6eec42](https://github.com/sentry-kubernetes/charts/commit/d6eec42b2c31f42a473d1241721ff3d64111400f))

## [26.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.20.0...sentry-v26.0.0) (2024-10-24)


### ⚠ BREAKING CHANGES

Make sure to upgrade to chart version 25.20.0 (Seentry 24.8.0) before upgrading to 26.x.x

**Note:** In version [sentry-v25.19.0](https://github.com/sentry-kubernetes/charts/releases/tag/sentry-v26.5.0) ([commit](https://github.com/sentry-kubernetes/charts/commit/f5a12e04ee5ffa28f1d62bf6c7cb5c733b30c2b9)), SASL authentication functionality for Kafka was added, which broke backward compatibility when using an external Kafka cluster. The single-host external kafka setup works correctly. The [issue #1584](https://github.com/sentry-kubernetes/charts/issues/1584) was fixed in version [sentry-v26.5.0](https://github.com/sentry-kubernetes/charts/releases/tag/sentry-v26.5.0) ([commit](https://github.com/sentry-kubernetes/charts/commit/889bd0d47235cb1ab5a7b52439f5b8df61026a03)). In this case, for a sequential upgrade, a viable workaround could be to use [sentry-v26.5.0](https://github.com/sentry-kubernetes/charts/releases/tag/sentry-v26.5.0) with `appVersion: 24.8.0` initially ([Chart.yml](https://github.com/sentry-kubernetes/charts/blob/sentry-v26.5.0/charts/sentry/Chart.yaml#L6)), and then use [sentry-v26.5.0](https://github.com/sentry-kubernetes/charts/releases/tag/sentry-v26.5.0) as is ([details](https://github.com/sentry-kubernetes/charts/pull/1588#issuecomment-2459117235)).

### Features

* add maxTasksPerChild option to Sentry worker deployments ([#1572](https://github.com/sentry-kubernetes/charts/issues/1572)) ([bc32900](https://github.com/sentry-kubernetes/charts/commit/bc329004f46f4af7ecf4a99f07e74e28dbee436e))
* update sentry appVersion to 24.9.0 ([#1571](https://github.com/sentry-kubernetes/charts/issues/1571)) ([2a3a030](https://github.com/sentry-kubernetes/charts/commit/2a3a030ba3c61c6792712c4f637fe64d42a47fe2))

## [25.20.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.19.0...sentry-v25.20.0) (2024-10-23)


### Features

* update sentry appVersion to 24.8.0 ([#1569](https://github.com/sentry-kubernetes/charts/issues/1569)) ([cb731e0](https://github.com/sentry-kubernetes/charts/commit/cb731e0cba028907fff29ed9e1525e544694ec32))

## [25.19.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.18.0...sentry-v25.19.0) (2024-10-22)


### Features

* **clickhouse:** remove explicit imageVersion, inherit from chart ([#1561](https://github.com/sentry-kubernetes/charts/issues/1561)) ([4d003fd](https://github.com/sentry-kubernetes/charts/commit/4d003fdc350f1427d413285b94bf27fd13635239))
* **sentry:** add sasl auth for kafka and manage settings of connections ([#1557](https://github.com/sentry-kubernetes/charts/issues/1557)) ([f5a12e0](https://github.com/sentry-kubernetes/charts/commit/f5a12e04ee5ffa28f1d62bf6c7cb5c733b30c2b9))


### Bug Fixes

* **snuba:** Add missing --no-strict-offset-reset for replacer ([#1559](https://github.com/sentry-kubernetes/charts/issues/1559)) ([0c415e7](https://github.com/sentry-kubernetes/charts/commit/0c415e704fb2f2cbb984d3e0d5e3b08895834436))
* Use correct syntax for envFrom in web and worker ([#1563](https://github.com/sentry-kubernetes/charts/issues/1563)) ([b834c0e](https://github.com/sentry-kubernetes/charts/commit/b834c0e4651633ca88e4c1839d60c0c69cf52087))

## [25.18.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.17.1...sentry-v25.18.0) (2024-10-16)


### Features

* **clickhouse:** update ClickHouse chart to 3.12.0 ([#1556](https://github.com/sentry-kubernetes/charts/issues/1556)) ([07e73c1](https://github.com/sentry-kubernetes/charts/commit/07e73c1846c242f1babaa1ed47271588c9ec2daf))

## [25.17.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.17.0...sentry-v25.17.1) (2024-10-15)


### Bug Fixes

* external redis functionality for relay ([#1548](https://github.com/sentry-kubernetes/charts/issues/1548)) ([6e71fc1](https://github.com/sentry-kubernetes/charts/commit/6e71fc169622c2e7e4934bfefd613f613a6c77d2))

## [25.17.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.16.0...sentry-v25.17.0) (2024-10-14)


### Features

* add logLevel and logFormat options for worker events and transactions ([#1542](https://github.com/sentry-kubernetes/charts/issues/1542)) ([bfbdd4d](https://github.com/sentry-kubernetes/charts/commit/bfbdd4d95bf15b18a72ed3d5af2baa363e98d6b6))

## [25.16.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.15.1...sentry-v25.16.0) (2024-10-14)


### Features

* **snuba:** add events_analytics_platform to settings ([#1540](https://github.com/sentry-kubernetes/charts/issues/1540)) ([b035b10](https://github.com/sentry-kubernetes/charts/commit/b035b10fb96d7081abcab8cf03a5f63e814a4871))

## [25.15.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.15.0...sentry-v25.15.1) (2024-10-14)


### Bug Fixes

* conditionally set auto-offset-reset for snuba subscription consumers ([#1538](https://github.com/sentry-kubernetes/charts/issues/1538)) ([db26b85](https://github.com/sentry-kubernetes/charts/commit/db26b853246e8f213d25f8c5041893e54a556630))

## [25.15.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.14.0...sentry-v25.15.0) (2024-10-13)


### Features

* **sentry:** Add missing --no-strict-offset-reset and --auto-offset-reset for consumers ([#1535](https://github.com/sentry-kubernetes/charts/issues/1535)) ([8e0eea0](https://github.com/sentry-kubernetes/charts/commit/8e0eea0e5a3805c93d19ea93240d634953461cea))

## [25.14.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.13.4...sentry-v25.14.0) (2024-10-13)


### Features

* offset-reset in ds ([#1533](https://github.com/sentry-kubernetes/charts/issues/1533)) ([0e3ef2d](https://github.com/sentry-kubernetes/charts/commit/0e3ef2db47c552fc80d07442263764a33c11c0d3))

## [25.13.4](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.13.3...sentry-v25.13.4) (2024-10-13)


### Bug Fixes

* symbolicator storage class ([#1530](https://github.com/sentry-kubernetes/charts/issues/1530)) ([26cbaab](https://github.com/sentry-kubernetes/charts/commit/26cbaab28dcb0c95ac10723ed62b453c678b9787))

## [25.13.3](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.13.2...sentry-v25.13.3) (2024-10-12)


### Bug Fixes

* update geoip job hooks and volume handling ([#1529](https://github.com/sentry-kubernetes/charts/issues/1529)) ([886eb5f](https://github.com/sentry-kubernetes/charts/commit/886eb5fe8110bfb1a973740ca3a1a2e3e776c003))

## [25.13.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.13.1...sentry-v25.13.2) (2024-10-08)


### Bug Fixes

* correct storageClass handling for geodata persistence ([#1524](https://github.com/sentry-kubernetes/charts/issues/1524)) ([b2f568d](https://github.com/sentry-kubernetes/charts/commit/b2f568d926771208256d47f03a2f39806ca94fe3))

## [25.13.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.13.0...sentry-v25.13.1) (2024-10-08)


### Bug Fixes

* correct argument order of consumers ([#1522](https://github.com/sentry-kubernetes/charts/issues/1522)) ([6236a74](https://github.com/sentry-kubernetes/charts/commit/6236a74e70a78525a6030ade5cd3fc29b424fe59))

## [25.13.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.12.0...sentry-v25.13.0) (2024-10-07)


### Features

* add geoip support to sentry deployment ([#1516](https://github.com/sentry-kubernetes/charts/issues/1516)) ([4f2429b](https://github.com/sentry-kubernetes/charts/commit/4f2429b746fe13002c21abf233338a293acff1a0))

## [25.12.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.11.1...sentry-v25.12.0) (2024-10-07)


### Features

* add existingSecretEnv support for web and worker deployments ([#1509](https://github.com/sentry-kubernetes/charts/issues/1509)) ([b170ac3](https://github.com/sentry-kubernetes/charts/commit/b170ac33a64e41a36bfeb416e05801ec9ae1365d))
* allow customization of kafka configuration ([#1514](https://github.com/sentry-kubernetes/charts/issues/1514)) ([5f4009b](https://github.com/sentry-kubernetes/charts/commit/5f4009b97898bea66749436b792e4a9815df4be8))


### Bug Fixes

* user-create-job hook does not create user ([5f4009b](https://github.com/sentry-kubernetes/charts/commit/5f4009b97898bea66749436b792e4a9815df4be8))

## [25.11.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.11.0...sentry-v25.11.1) (2024-10-01)


### Bug Fixes

* reintroduced "Extend Redis functionality" ([#1492](https://github.com/sentry-kubernetes/charts/issues/1492)) broke S3 existing secret (from commit 0b7a7b4c) ([#1499](https://github.com/sentry-kubernetes/charts/issues/1499)) ([3eb75ef](https://github.com/sentry-kubernetes/charts/commit/3eb75ef861c68279975d2baa846bdf9b678474f3))

## [25.11.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.10.1...sentry-v25.11.0) (2024-09-30)


### Features

* reintroduce "Extend Redis functionality" ([#1492](https://github.com/sentry-kubernetes/charts/issues/1492)) ([0b7a7b4](https://github.com/sentry-kubernetes/charts/commit/0b7a7b4c874bf4d4a460c88bb259cab0e025f7ee))

## [25.10.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.10.0...sentry-v25.10.1) (2024-09-30)


### Bug Fixes

* add topic partition counts in snuba config for correct ([#1489](https://github.com/sentry-kubernetes/charts/issues/1489)) ([2b44fb2](https://github.com/sentry-kubernetes/charts/commit/2b44fb2a449410a64aa4628e06fdd4e1cb1ae6aa))
* configuring kafka to use zookeeper uses only brokers, and service name in db-check is wrong ([#1494](https://github.com/sentry-kubernetes/charts/issues/1494)) ([34d4975](https://github.com/sentry-kubernetes/charts/commit/34d49752a9869372a69ce6add1011be1155ec254))

## [25.10.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.9.0...sentry-v25.10.0) (2024-09-25)


### Features

* update kafka for fix jmx-exporter scrape path ([#1477](https://github.com/sentry-kubernetes/charts/issues/1477)) ([a1c6250](https://github.com/sentry-kubernetes/charts/commit/a1c6250f70245f6514ddbe8e15741250bd6de1a2))

## [25.9.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.8.1...sentry-v25.9.0) (2024-09-18)


### Features

* add logLevel option to ingestConsumerAttachments ([#1468](https://github.com/sentry-kubernetes/charts/issues/1468)) ([8005f0f](https://github.com/sentry-kubernetes/charts/commit/8005f0fcebf9856a3a29a99f596452a2c481a58c))

## [25.8.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.8.0...sentry-v25.8.1) (2024-09-17)


### Bug Fixes

* correct nginx.conf and ingress settings for sentry 24.7.1 and ([#1466](https://github.com/sentry-kubernetes/charts/issues/1466)) ([cfb90ef](https://github.com/sentry-kubernetes/charts/commit/cfb90efd05b7b1b03cf191df4324e2092f50e4dc))
* correct order of arguments of sentry consumers ([#1463](https://github.com/sentry-kubernetes/charts/issues/1463)) ([#1464](https://github.com/sentry-kubernetes/charts/issues/1464)) ([2861efa](https://github.com/sentry-kubernetes/charts/commit/2861efa7192b8d8bc02835ef4ade16a21b2729f1))

## [25.8.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.7.0...sentry-v25.8.0) (2024-09-16)


### Features

* add logging and worker settings to Sentry web deployment ([#1459](https://github.com/sentry-kubernetes/charts/issues/1459)) ([f0427e2](https://github.com/sentry-kubernetes/charts/commit/f0427e219773382eee4580bc4170d221f5150eee))

## [25.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.6.0...sentry-v25.7.0) (2024-09-14)


### Features

* **symbolicator:** implement deployment and statefulset selection ([#1453](https://github.com/sentry-kubernetes/charts/issues/1453)) ([112c1b5](https://github.com/sentry-kubernetes/charts/commit/112c1b50456273163f6692d16787c4d04fe87cda))

## [25.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.5.1...sentry-v25.6.0) (2024-09-14)


### Features

* updated sentry to 24.7.1 ([#1454](https://github.com/sentry-kubernetes/charts/issues/1454)) ([7874e56](https://github.com/sentry-kubernetes/charts/commit/7874e569217e8469c5ce40087ecd656309a01bba))

## [25.5.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.5.0...sentry-v25.5.1) (2024-09-12)


### Bug Fixes

* correct podLabels type from list to map in values.yaml ([#1448](https://github.com/sentry-kubernetes/charts/issues/1448)) ([0c34ecc](https://github.com/sentry-kubernetes/charts/commit/0c34ecca3874c4ff1162c76457993bbe29238b96))
* invalid parameter in deployments ([#1446](https://github.com/sentry-kubernetes/charts/issues/1446)) ([dbafa66](https://github.com/sentry-kubernetes/charts/commit/dbafa66025fd9ecb3eb4b07a5df53f97221e77da))

## [25.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.4.0...sentry-v25.5.0) (2024-09-11)


### Features

* enhance nginx config to handle disabled sentry relay ([#1430](https://github.com/sentry-kubernetes/charts/issues/1430)) ([4395dba](https://github.com/sentry-kubernetes/charts/commit/4395dba949ca41375bcf0c24435344406cc2bbb7))

## [25.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.3.0...sentry-v25.4.0) (2024-09-10)


### Features

* add cache, logging, and kafka configuration options to sentry relay ([#1438](https://github.com/sentry-kubernetes/charts/issues/1438)) ([4a84c9f](https://github.com/sentry-kubernetes/charts/commit/4a84c9f5168969e044c0303ca81b60ce743303fd))
* add excludequeues option to sentry worker deployment ([#1441](https://github.com/sentry-kubernetes/charts/issues/1441)) ([78e80fb](https://github.com/sentry-kubernetes/charts/commit/78e80fb35677b1174e9d6d5dcbc37f58a32b86ac))

## [25.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.2.2...sentry-v25.3.0) (2024-09-05)


### Features

* enhance logging options and add missing configuration parameters ([#1419](https://github.com/sentry-kubernetes/charts/issues/1419)) ([c666226](https://github.com/sentry-kubernetes/charts/commit/c666226346114998ff3c04a005d494e79bd7e13e))

## [25.2.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.2.1...sentry-v25.2.2) (2024-09-04)


### Bug Fixes

* remove invalid --max-batch-size and --processes parameters from some consumers ([#1416](https://github.com/sentry-kubernetes/charts/issues/1416)) ([e42dc12](https://github.com/sentry-kubernetes/charts/commit/e42dc12e9bddee1e4d42db7173901ccde0cd3371))

## [25.2.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.2.0...sentry-v25.2.1) (2024-09-03)


### Bug Fixes

* del --max-batch-time-ms and enable maxBatchTimeMs in values ([#1412](https://github.com/sentry-kubernetes/charts/issues/1412)) ([086b477](https://github.com/sentry-kubernetes/charts/commit/086b47720b8fe0ee15fd65eafc5446dccc903366))
* discord template typos ([#1408](https://github.com/sentry-kubernetes/charts/issues/1408)) ([044cc25](https://github.com/sentry-kubernetes/charts/commit/044cc254873911ae668e1c6bd1a34ac0883a1db8))

## [25.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.1.0...sentry-v25.2.0) (2024-09-02)


### Features

* add logLevel, maxPollIntervalMs, inputBlockSize, maxBatchTimeMs ([#1403](https://github.com/sentry-kubernetes/charts/issues/1403)) ([78de49b](https://github.com/sentry-kubernetes/charts/commit/78de49b0f94633cf098aff320a79d7a48443b9a5))

## [25.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.0.1...sentry-v25.1.0) (2024-08-26)


### Features

* add noStrictOffsetReset for ingest-consumer-attachments ([#1398](https://github.com/sentry-kubernetes/charts/issues/1398)) ([599294c](https://github.com/sentry-kubernetes/charts/commit/599294c33b9e5dfd076e581386a614f60fca38ef))

## [25.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v25.0.0...sentry-v25.0.1) (2024-08-23)


### Bug Fixes

* clickhouse replicas 1 ([d789562](https://github.com/sentry-kubernetes/charts/commit/d789562cbde4371b0057272976a981f66229ca50))

## [25.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v24.0.1...sentry-v25.0.0) (2024-08-23)


### ⚠ BREAKING CHANGES

* change default values again

### Bug Fixes

* change default values again ([a282b7e](https://github.com/sentry-kubernetes/charts/commit/a282b7e718c37c7d5d25aef19b6372ae00180ab0))

## [24.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v24.0.0...sentry-v24.0.1) (2024-08-22)


### Bug Fixes

* revert ClickHouse replicas number ([#1392](https://github.com/sentry-kubernetes/charts/issues/1392)) ([ad6fc29](https://github.com/sentry-kubernetes/charts/commit/ad6fc293e627f78f15b960b8d8cbc0d606cd194f))

## [24.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.12.1...sentry-v24.0.0) (2024-08-19)


### ⚠ BREAKING CHANGES

* deployment default values ([#1379](https://github.com/sentry-kubernetes/charts/issues/1379))

### Features

* add optional relabeling configs to serviceMonitor object ([#1390](https://github.com/sentry-kubernetes/charts/issues/1390)) ([4f6e440](https://github.com/sentry-kubernetes/charts/commit/4f6e440c5c69ab728a2e9ac9a56b55ce274c5dc1))


### Bug Fixes

* deployment default values ([#1379](https://github.com/sentry-kubernetes/charts/issues/1379)) ([72376fd](https://github.com/sentry-kubernetes/charts/commit/72376fd0aeb9d7fdb6b30a275ae59429bb88da12))

## [23.12.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.12.0...sentry-v23.12.1) (2024-07-19)


### Bug Fixes

* update memcached chart to 7.4.8 ([#1352](https://github.com/sentry-kubernetes/charts/issues/1352)) ([a39ae5b](https://github.com/sentry-kubernetes/charts/commit/a39ae5b5252b0535f76ee1dbaccf723dbc1bd6fb))

## [23.12.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.11.0...sentry-v23.12.0) (2024-07-11)


### Features

* add parameters for web workers TTL ([#1355](https://github.com/sentry-kubernetes/charts/issues/1355)) ([a1b218f](https://github.com/sentry-kubernetes/charts/commit/a1b218f69a8ea20a987e11a94dbf052d5a05d3a8))


### Bug Fixes

* remove 'profiling-global-suspect-functions' as it is not supported on self hosted ([#1358](https://github.com/sentry-kubernetes/charts/issues/1358)) ([25004f6](https://github.com/sentry-kubernetes/charts/commit/25004f67e4cba551bb78d5c42af80d2e631c50de))

## [23.11.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.10.0...sentry-v23.11.0) (2024-06-24)


### Features

* add multiprocess to postProcessForwardTransactions ([#1334](https://github.com/sentry-kubernetes/charts/issues/1334)) ([9de6968](https://github.com/sentry-kubernetes/charts/commit/9de696813a5e407f4ddf3657d19519500088e7d3))

## [23.10.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.9.1...sentry-v23.10.0) (2024-06-21)


### Features

* add insights feature flags ([#1329](https://github.com/sentry-kubernetes/charts/issues/1329)) ([6cccdbd](https://github.com/sentry-kubernetes/charts/commit/6cccdbd1a8703c6f0a0d417654358e11e7275bce))

## [23.9.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.9.0...sentry-v23.9.1) (2024-06-17)


### Bug Fixes

* template fails when existingSecretKeys is undefined ([#1323](https://github.com/sentry-kubernetes/charts/issues/1323)) ([4808c6f](https://github.com/sentry-kubernetes/charts/commit/4808c6ff76f53820c9ec8a25fd77ac42f0395d66))

## [23.9.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.8.0...sentry-v23.9.0) (2024-06-17)


### Features

* Configure external postgres with values from secret ([#1279](https://github.com/sentry-kubernetes/charts/issues/1279)) ([adfb64d](https://github.com/sentry-kubernetes/charts/commit/adfb64da1dcd6ba109b64fe2e7496e88d65b38a9))

## [23.8.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.7.0...sentry-v23.8.0) (2024-06-16)


### Features

* discord integration ([#1318](https://github.com/sentry-kubernetes/charts/issues/1318)) ([d480620](https://github.com/sentry-kubernetes/charts/commit/d480620b3d60d983b239a5a59f063b05a4234ecc))

## [23.7.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.6.0...sentry-v23.7.0) (2024-06-11)


### Features

* **deps:** update kafka helm to v29 ([#1285](https://github.com/sentry-kubernetes/charts/issues/1285)) ([5b24013](https://github.com/sentry-kubernetes/charts/commit/5b240133bd5f40202e9a86b9744eb32ed512da97))
* **deps:** update nginx docker tag to v18 ([#1301](https://github.com/sentry-kubernetes/charts/issues/1301)) ([161aed6](https://github.com/sentry-kubernetes/charts/commit/161aed65c60672972dd21c242a830f33a7d837ea))

## [23.6.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.5.2...sentry-v23.6.0) (2024-06-10)


### Features

* add optional LogLevel parameter to sentry cleanup job and custom location snippet to nginx conf ([cd38e67](https://github.com/sentry-kubernetes/charts/commit/cd38e67121b04d5e4b060aaa97ae8378c837846e))


### Bug Fixes

* fix custom features ([#1309](https://github.com/sentry-kubernetes/charts/issues/1309)) ([7490ec3](https://github.com/sentry-kubernetes/charts/commit/7490ec3bbf1efeebf780b8f3aec3aa70d177d4e4))

## [23.5.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.5.1...sentry-v23.5.2) (2024-06-08)


### Bug Fixes

* **snuba:** add profile_chunks to the storage sets ([#1307](https://github.com/sentry-kubernetes/charts/issues/1307)) ([df812f7](https://github.com/sentry-kubernetes/charts/commit/df812f7cf4ba28006a59c0fa49a527feac50a184))

## [23.5.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.5.0...sentry-v23.5.1) (2024-06-07)


### Bug Fixes

* **deployment-relay:** fix relay init container volume mounts ([#861](https://github.com/sentry-kubernetes/charts/issues/861)) ([72314d5](https://github.com/sentry-kubernetes/charts/commit/72314d5a5dcc53a7562e0066a54b62ac4f9eb3e0))

## [23.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.4.1...sentry-v23.5.0) (2024-06-07)


### Features

* 24.5.1 update ([6e628ad](https://github.com/sentry-kubernetes/charts/commit/6e628adc200525ebe57e9977328d8dd8b5eea471))

## [23.4.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.4.0...sentry-v23.4.1) (2024-06-06)


### Bug Fixes

* relay topic ([1ae5f66](https://github.com/sentry-kubernetes/charts/commit/1ae5f66a24260c96ae4711f1f880220f33150148))

## [23.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.3.0...sentry-v23.4.0) (2024-06-06)


### Features

* add-custom-features to configmap ([#1297](https://github.com/sentry-kubernetes/charts/issues/1297)) ([300aea0](https://github.com/sentry-kubernetes/charts/commit/300aea0dfc6293892e450d359daa63ae3619ace5))

## [23.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.2.0...sentry-v23.3.0) (2024-06-04)


### Features

* topologySpreadConstraint ([#1291](https://github.com/sentry-kubernetes/charts/issues/1291)) ([bc0d4e6](https://github.com/sentry-kubernetes/charts/commit/bc0d4e64987c1ea5e4d3b1386ce45ea94c3dd15b))

## [23.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.1.0...sentry-v23.2.0) (2024-06-03)


### Features

* allow to configure extra manifest through values ([#1278](https://github.com/sentry-kubernetes/charts/issues/1278)) ([3fec182](https://github.com/sentry-kubernetes/charts/commit/3fec18254de4675077f57f7783403317fc1bdad7))
* dependency update before push chart ([#1283](https://github.com/sentry-kubernetes/charts/issues/1283)) ([2c2b6c2](https://github.com/sentry-kubernetes/charts/commit/2c2b6c2d966c137a7c4251eb4c81b186f886c63e))
* supports ipv6 ([#1292](https://github.com/sentry-kubernetes/charts/issues/1292)) ([b920e3f](https://github.com/sentry-kubernetes/charts/commit/b920e3f2159f8c3e124f09cc48b29ba5aae5aedb))


### Bug Fixes

* ipv6 ([b904c79](https://github.com/sentry-kubernetes/charts/commit/b904c7935c9d51903017c1e14f74bf122cfaddde))

## [23.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.0.3...sentry-v23.1.0) (2024-05-23)


### Features

* bump sentry to 24.5.0 ([#1270](https://github.com/sentry-kubernetes/charts/issues/1270)) ([7d53050](https://github.com/sentry-kubernetes/charts/commit/7d53050f8c9bda2b2fca686685e44823706dc263))


### Bug Fixes

* **worker:** workerTransactions should be disabled by default ([#1275](https://github.com/sentry-kubernetes/charts/issues/1275)) ([6090619](https://github.com/sentry-kubernetes/charts/commit/6090619d326b420f6c177114ec55a5ef84f3a075))

## [23.0.3](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.0.2...sentry-v23.0.3) (2024-05-22)


### Bug Fixes

* typo in deployment-snuba-subscription-consumer-metrics.yaml [#1271](https://github.com/sentry-kubernetes/charts/issues/1271) ([d667d0c](https://github.com/sentry-kubernetes/charts/commit/d667d0cd18e36af06e6ba3050a850265df540e1d))

## [23.0.2](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.0.1...sentry-v23.0.2) (2024-05-16)


### Bug Fixes

* worker hpa ([#1263](https://github.com/sentry-kubernetes/charts/issues/1263)) ([0b55646](https://github.com/sentry-kubernetes/charts/commit/0b55646e696f6be42755b58308f3127532a60d70))

## [23.0.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v23.0.0...sentry-v23.0.1) (2024-05-15)


### Bug Fixes

* fix worker deployments ([#1261](https://github.com/sentry-kubernetes/charts/issues/1261)) ([eb3e7af](https://github.com/sentry-kubernetes/charts/commit/eb3e7af7f0e74fee19c10a08d1dcd193bd8de429))

## [23.0.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.5.1...sentry-v23.0.0) (2024-05-14)


### ⚠ BREAKING CHANGES

* ingest consumers and workers separation ([#1245](https://github.com/sentry-kubernetes/charts/issues/1245))

### Features

* ingest consumers and workers separation ([#1245](https://github.com/sentry-kubernetes/charts/issues/1245)) ([5969544](https://github.com/sentry-kubernetes/charts/commit/596954497af0acef2cce4014056ca756c5eb3592))


### Bug Fixes

* fix order snuba-outcomes-billing-consumer args ([#1257](https://github.com/sentry-kubernetes/charts/issues/1257)) ([0645404](https://github.com/sentry-kubernetes/charts/commit/06454040e45fd3d13236d011802a1e6436da5f8a))

## [22.5.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.5.0...sentry-v22.5.1) (2024-05-14)


### Bug Fixes

* fix snuba-outcomes-billing-consumer args ([#1254](https://github.com/sentry-kubernetes/charts/issues/1254)) ([ac821d6](https://github.com/sentry-kubernetes/charts/commit/ac821d61f94bcedd399b970f4c58e605c1d04602))

## [22.5.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.4.0...sentry-v22.5.0) (2024-05-14)


### Features

* bump sentry to 24.4.2 ([#1248](https://github.com/sentry-kubernetes/charts/issues/1248)) ([c4ea3fb](https://github.com/sentry-kubernetes/charts/commit/c4ea3fbf8b646de66251f37521f744ac84228a9b))

## [22.4.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.3.0...sentry-v22.4.0) (2024-05-08)


### Features

* checksum only for configmap contents ([#1228](https://github.com/sentry-kubernetes/charts/issues/1228)) ([97829b0](https://github.com/sentry-kubernetes/charts/commit/97829b0e0ebf705ec3083d3d01e52b4d09200946))


### Bug Fixes

* actualize Sentry consumer additional options usage ([#1244](https://github.com/sentry-kubernetes/charts/issues/1244)) ([e24d459](https://github.com/sentry-kubernetes/charts/commit/e24d4596feeb6b1fc7fe9da806d1bac2c43bcfc6))

## [22.3.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.2.1...sentry-v22.3.0) (2024-04-29)


### Features

* Add liveness to consumers ([#1240](https://github.com/sentry-kubernetes/charts/issues/1240)) ([60aaa3d](https://github.com/sentry-kubernetes/charts/commit/60aaa3d5f485320dc3bca1161b786cb20df34b73))

## [22.2.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.2.0...sentry-v22.2.1) (2024-04-24)


### Bug Fixes

* issues with nginx configuration for metrics ([#1232](https://github.com/sentry-kubernetes/charts/issues/1232)) ([b227a6b](https://github.com/sentry-kubernetes/charts/commit/b227a6b801d244dba9baf7180eeaaaef96dfccc3))
* sentry metrics deployment annotations ([#1239](https://github.com/sentry-kubernetes/charts/issues/1239)) ([59c6245](https://github.com/sentry-kubernetes/charts/commit/59c6245f0b79b6eafff14e301cd1378cbb432bc7))

## [22.2.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.1.1...sentry-v22.2.0) (2024-04-17)


### Features

* added flags on individual components ([#1188](https://github.com/sentry-kubernetes/charts/issues/1188)) ([fb4d6f1](https://github.com/sentry-kubernetes/charts/commit/fb4d6f14b50c545a798b3a27012f28013d36e2d5))
* update kafka topic provisioning config ([#1134](https://github.com/sentry-kubernetes/charts/issues/1134)) ([cd508ff](https://github.com/sentry-kubernetes/charts/commit/cd508ff4e02b44189eae30d993deb3fb368fd5ee))


### Bug Fixes

* kafka.listeners.interBroker typo ([#1222](https://github.com/sentry-kubernetes/charts/issues/1222)) ([63e7062](https://github.com/sentry-kubernetes/charts/commit/63e70626a6bb0ea4caeac8dfd80b216ffcfe9c28))

## [22.1.1](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.1.0...sentry-v22.1.1) (2024-04-15)


### Bug Fixes

* When set to controller only, port 9092 is not listened on ([#1218](https://github.com/sentry-kubernetes/charts/issues/1218)) ([d5cbba6](https://github.com/sentry-kubernetes/charts/commit/d5cbba6b65da9f77f78299ddc9b07c24fd7b3cef))

## [22.1.0](https://github.com/sentry-kubernetes/charts/compare/sentry-v22.0.2...sentry-v22.1.0) (2024-04-12)


### Features

* 1.0.0 ([9c5b70c](https://github.com/sentry-kubernetes/charts/commit/9c5b70c6396fd9974001e403cc11f92ccb61a011))
* 11.0.0 ([9d333e6](https://github.com/sentry-kubernetes/charts/commit/9d333e6f259dad0444b349d839cdde0187f64cc9))
* 11.2.0 ([0569872](https://github.com/sentry-kubernetes/charts/commit/05698720bc8a5eedcbaa847f766ac6a669360ec5))
* 21.4.0 release ([#356](https://github.com/sentry-kubernetes/charts/issues/356)) ([84c56ac](https://github.com/sentry-kubernetes/charts/commit/84c56ac5417c94a15ec53374b63fe56ab5e9b9a2))
* 9.0.0 ([d659dcb](https://github.com/sentry-kubernetes/charts/commit/d659dcbbea17eacf20653a6ca386ed233bd690f2))
* ability to use existingSecret for psql ([#148](https://github.com/sentry-kubernetes/charts/issues/148)) ([8c02d7a](https://github.com/sentry-kubernetes/charts/commit/8c02d7ae67c5fc0d161e739e9968b6d272acc259))
* add `existingSecret` param for Github ([#863](https://github.com/sentry-kubernetes/charts/issues/863)) ([8d43592](https://github.com/sentry-kubernetes/charts/commit/8d43592fe3f3a22e3189bd84995e5cecccd088be))
* add podLabels to Sentry hooks ([#659](https://github.com/sentry-kubernetes/charts/issues/659)) ([50b8f1e](https://github.com/sentry-kubernetes/charts/commit/50b8f1e8879e22dcf7d10035b64c8ffa2b7e41ae))
* add pvc to clickhouse ([#50](https://github.com/sentry-kubernetes/charts/issues/50)) ([197930f](https://github.com/sentry-kubernetes/charts/commit/197930f1a29bbf038351fbc72d401297140fc857))
* add sentry cleanup cronjob ([#178](https://github.com/sentry-kubernetes/charts/issues/178)) ([ae42bc4](https://github.com/sentry-kubernetes/charts/commit/ae42bc4b4783f7515cf4e8620576568a6cb6ff5c))
* add service account names for cronjobs ([#681](https://github.com/sentry-kubernetes/charts/issues/681)) ([0bc212d](https://github.com/sentry-kubernetes/charts/commit/0bc212daf3a999019d035deaed979f157f69d8ad))
* add share process namespace to hook jobs ([#688](https://github.com/sentry-kubernetes/charts/issues/688)) ([b81316d](https://github.com/sentry-kubernetes/charts/commit/b81316d4b524e19b6f2968c7552f76c47ef33368))
* add support for configuring email by env variables ([#87](https://github.com/sentry-kubernetes/charts/issues/87)) ([5e91477](https://github.com/sentry-kubernetes/charts/commit/5e91477cb61b8edb3b54734f899dd9560288417b))
* add support of GCS without secret, using GKE ServiceAccount ([#264](https://github.com/sentry-kubernetes/charts/issues/264)) ([e42656e](https://github.com/sentry-kubernetes/charts/commit/e42656ee3f5d88b9b7ba07ceba15d02c82fb544c))
* Add tolerations to user-create hook ([#615](https://github.com/sentry-kubernetes/charts/issues/615)) ([f347039](https://github.com/sentry-kubernetes/charts/commit/f347039cc4ff0f9a9e9237d9c6785d39bc46280c))
* added (partial) support for Symbolicator deployment ([#213](https://github.com/sentry-kubernetes/charts/issues/213)) ([098fdef](https://github.com/sentry-kubernetes/charts/commit/098fdef2af7b1f7b53c596cb6127d70c1d49bcea))
* added activeDeadlineSeconds to all jobs ([#683](https://github.com/sentry-kubernetes/charts/issues/683)) ([2418ba8](https://github.com/sentry-kubernetes/charts/commit/2418ba8c38a85991c9c9eb5a281bfb3d5d72a020))
* added cpu hpa for worker - remove replica if hpa ([#74](https://github.com/sentry-kubernetes/charts/issues/74)) ([5a14b8b](https://github.com/sentry-kubernetes/charts/commit/5a14b8b59c786eaa352c521dea00feb765cc2dc1))
* added different types of snuba consumers ([#83](https://github.com/sentry-kubernetes/charts/issues/83)) ([951cf38](https://github.com/sentry-kubernetes/charts/commit/951cf38c08a548e3db92d7848b6d1e6205d40b66))
* added env var config for init jobs ([#124](https://github.com/sentry-kubernetes/charts/issues/124)) ([5cec614](https://github.com/sentry-kubernetes/charts/commit/5cec61417e243ce49fe509f6bc62847add0975d0))
* added hpa for the web deployment ([#36](https://github.com/sentry-kubernetes/charts/issues/36)) ([b89ca49](https://github.com/sentry-kubernetes/charts/commit/b89ca49bf38af686bc69ff5f3ad0fb3392a2dbb2))
* added post process forwarder ([#9](https://github.com/sentry-kubernetes/charts/issues/9)) ([686613a](https://github.com/sentry-kubernetes/charts/commit/686613a31572d2bd54d5153d4d44c5ba8bc77ac2))
* added redis worker ([#10](https://github.com/sentry-kubernetes/charts/issues/10)) ([9e1cc7a](https://github.com/sentry-kubernetes/charts/commit/9e1cc7a046615856b50f17e232a9901bdc6204a9))
* allow custom mode for sentry-relay ([#197](https://github.com/sentry-kubernetes/charts/issues/197)) ([a78b5f1](https://github.com/sentry-kubernetes/charts/commit/a78b5f1f061fad910cd679bb9eca083f04607de6))
* allow some snuba deployments to be pushed as hooks ([#198](https://github.com/sentry-kubernetes/charts/issues/198)) ([9bda4ee](https://github.com/sentry-kubernetes/charts/commit/9bda4ee401664382f54932adfd7135820bc45d1d))
* allow to configure running relay as a hook ([#183](https://github.com/sentry-kubernetes/charts/issues/183)) ([652a838](https://github.com/sentry-kubernetes/charts/commit/652a8386a4f84a0fa8319b7afda3d3c1784c3d06))
* allow to specify Recreate strategy type for sentry-web ([#216](https://github.com/sentry-kubernetes/charts/issues/216)) ([0179c79](https://github.com/sentry-kubernetes/charts/commit/0179c79fe490e1f44a3e54f6bcc8ff0f37a78d92))
* allows revisionHistoryLimit ([#339](https://github.com/sentry-kubernetes/charts/issues/339)) ([65545c8](https://github.com/sentry-kubernetes/charts/commit/65545c87c98c3af930897f08f4d095f67beb3027))
* bump sentry dependencies ([#1099](https://github.com/sentry-kubernetes/charts/issues/1099)) ([dccd183](https://github.com/sentry-kubernetes/charts/commit/dccd183760ee92aab2592333d8dc1a23d7411466))
* configure Slack based on current documentation ([#189](https://github.com/sentry-kubernetes/charts/issues/189)) ([5c4447c](https://github.com/sentry-kubernetes/charts/commit/5c4447cd5f2055ac7356face9e19fa552adb5e77))
* december release ([#245](https://github.com/sentry-kubernetes/charts/issues/245)) ([ec588a9](https://github.com/sentry-kubernetes/charts/commit/ec588a94520555e512b1b931eb5799e6d08293c9))
* distributed tables v2 ([#588](https://github.com/sentry-kubernetes/charts/issues/588)) ([cfe7d73](https://github.com/sentry-kubernetes/charts/commit/cfe7d736278feeeb72189efb841a6099685ed1dd))
* history limits for cronjobs ([#682](https://github.com/sentry-kubernetes/charts/issues/682)) ([f13da86](https://github.com/sentry-kubernetes/charts/commit/f13da86b541aa8645f1e7a72e54ea3df5ad6f7b2))
* hpa for snuba ([#42](https://github.com/sentry-kubernetes/charts/issues/42)) ([36a6e10](https://github.com/sentry-kubernetes/charts/commit/36a6e10f87e2b124b2a6527901ac49454a6a29e2))
* ingress ([#19](https://github.com/sentry-kubernetes/charts/issues/19)) ([a5fad21](https://github.com/sentry-kubernetes/charts/commit/a5fad21db773e664f2b51df0522f411b9be30698))
* initial beta 0.5.0 ([51866df](https://github.com/sentry-kubernetes/charts/commit/51866df56c518d28c74937c6b5119cd683d667f0))
* kafka fix db check ([a148a57](https://github.com/sentry-kubernetes/charts/commit/a148a57d7480e23adc912fe8700914792bea9807))
* kafka ha ([#35](https://github.com/sentry-kubernetes/charts/issues/35)) ([3b581f0](https://github.com/sentry-kubernetes/charts/commit/3b581f0b33d5d7d297c8bf110c70b7ae4b0796d2))
* **kafka:** enable kraft ([#1179](https://github.com/sentry-kubernetes/charts/issues/1179)) ([b01b26a](https://github.com/sentry-kubernetes/charts/commit/b01b26a15247daad77828d67b1cfa15a7c9cc95c))
* lint ([#1](https://github.com/sentry-kubernetes/charts/issues/1)) ([680d142](https://github.com/sentry-kubernetes/charts/commit/680d142670ae1972a27d473837b0884dc9f536f9))
* org subdomain disabled per default ([#248](https://github.com/sentry-kubernetes/charts/issues/248)) ([0819e79](https://github.com/sentry-kubernetes/charts/commit/0819e79bf71d2af2dc23a9347ee242945757a4d2))
* pass entire symbolicator config as yaml ([#335](https://github.com/sentry-kubernetes/charts/issues/335)) ([20d23b5](https://github.com/sentry-kubernetes/charts/commit/20d23b5369dd9ebca7c8fb7cd0f63c8012ef45b3))
* postgresql - and fix some issues ([#5](https://github.com/sentry-kubernetes/charts/issues/5)) ([70fa92d](https://github.com/sentry-kubernetes/charts/commit/70fa92dde31c7488f9303acfbd79813760fcebf7))
* profiling support ([#938](https://github.com/sentry-kubernetes/charts/issues/938)) ([b58f8a3](https://github.com/sentry-kubernetes/charts/commit/b58f8a34bbfab27ab0ff10bddcd8c23033b230fc))
* removal of hook resources can be configured ([#223](https://github.com/sentry-kubernetes/charts/issues/223)) ([32232da](https://github.com/sentry-kubernetes/charts/commit/32232da29ca7431084aea8048ef84da0ac1794f6))
* secret key generation ([#672](https://github.com/sentry-kubernetes/charts/issues/672)) ([559afc9](https://github.com/sentry-kubernetes/charts/commit/559afc90bfc7e2fdfd8b2d471ade5293f56c94d7))
* sentry 20.10.1 ([#211](https://github.com/sentry-kubernetes/charts/issues/211)) ([cb9c844](https://github.com/sentry-kubernetes/charts/commit/cb9c844592ac678fa1c86faafcf520a040f7d814))
* sentry 20.7.2 ([#126](https://github.com/sentry-kubernetes/charts/issues/126)) ([43197bc](https://github.com/sentry-kubernetes/charts/commit/43197bcefc51efc92eb51bac6efc4198e5b5c0f7))
* sentry 20.9.0 ([#182](https://github.com/sentry-kubernetes/charts/issues/182)) ([c7934ae](https://github.com/sentry-kubernetes/charts/commit/c7934aec90eb1231d6ad21d052ae50dca3c8bf21))
* sentry 22.10 & split post-process-forwarder ([#766](https://github.com/sentry-kubernetes/charts/issues/766)) ([ca611ef](https://github.com/sentry-kubernetes/charts/commit/ca611efde92be5deb7756ae05837e6ff1402f839))
* sentry january ([#291](https://github.com/sentry-kubernetes/charts/issues/291)) ([be0ba2a](https://github.com/sentry-kubernetes/charts/commit/be0ba2aa9baebe24bec119038e83fa6ffc56d75b))
* sentry june release ([#910](https://github.com/sentry-kubernetes/charts/issues/910)) ([96eb327](https://github.com/sentry-kubernetes/charts/commit/96eb3278775032e594bbf893f4fd4ef6d958a3de))
* sentry march release ([#333](https://github.com/sentry-kubernetes/charts/issues/333)) ([7408226](https://github.com/sentry-kubernetes/charts/commit/74082260202b8af97822d03b79f43cca61da9ca0))
* sentry may 2022 ([#623](https://github.com/sentry-kubernetes/charts/issues/623)) ([2a4cb0c](https://github.com/sentry-kubernetes/charts/commit/2a4cb0c4afe16720475f05405aac08e718acdead))
* **sentry:** adding statsd backend + prometheus-operator support ([#85](https://github.com/sentry-kubernetes/charts/issues/85)) ([7daee19](https://github.com/sentry-kubernetes/charts/commit/7daee1999c61934f937c751855d2746a78425456))
* **sentry:** bump clickhouse image to 19.17 ([#143](https://github.com/sentry-kubernetes/charts/issues/143)) ([3b80f57](https://github.com/sentry-kubernetes/charts/commit/3b80f578d8647ed1a549590c04376ed76cc4473f))
* **sentry:** enable snuba transactions consumer ([#142](https://github.com/sentry-kubernetes/charts/issues/142)) ([0203628](https://github.com/sentry-kubernetes/charts/commit/0203628f4c9d6e255ce163ceaa7997b89365c162))
* **sentry:** use AppVersion as the default image tag ([#141](https://github.com/sentry-kubernetes/charts/issues/141)) ([a0e79cf](https://github.com/sentry-kubernetes/charts/commit/a0e79cf8c834c79c1018c02452274a6f43d5ef73))
* separate config for external services ([#66](https://github.com/sentry-kubernetes/charts/issues/66)) ([5e80eba](https://github.com/sentry-kubernetes/charts/commit/5e80ebab63d8c78868edd63810789b47468b2986))
* smtp support use-ssl options ([#494](https://github.com/sentry-kubernetes/charts/issues/494)) ([bf8fdd5](https://github.com/sentry-kubernetes/charts/commit/bf8fdd596861a22bff74299f9d23b60644d7a08f))
* support for sentry relay & sentry 20.7.2 ([#144](https://github.com/sentry-kubernetes/charts/issues/144)) ([7ae3651](https://github.com/sentry-kubernetes/charts/commit/7ae365187da883efd891c351dc75c2e566112718))
* support partitions parameter for consumer events ([#566](https://github.com/sentry-kubernetes/charts/issues/566)) ([26128fe](https://github.com/sentry-kubernetes/charts/commit/26128fe808c33008c1660fda1271cef4381bf1fa))
* supports different values between redis&rabbitmq ([#16](https://github.com/sentry-kubernetes/charts/issues/16)) ([da70618](https://github.com/sentry-kubernetes/charts/commit/da7061889e42d66ce1085338f635fcbf9ed4c19d))
* supports github apps - sso ([#17](https://github.com/sentry-kubernetes/charts/issues/17)) ([90829bd](https://github.com/sentry-kubernetes/charts/commit/90829bd1bff956ae1d6815b1837985931b623d10))
* supports persistent workers ([#15](https://github.com/sentry-kubernetes/charts/issues/15)) ([ca63322](https://github.com/sentry-kubernetes/charts/commit/ca6332289753f333cfc3a0ce39942f7092eef01f))
* update clickhouse version ([#332](https://github.com/sentry-kubernetes/charts/issues/332)) ([3a6b012](https://github.com/sentry-kubernetes/charts/commit/3a6b0123d564ea10d65845123c6cec61659ea9f2))
* update rabbitmq-ha to allow setting affinity ([#110](https://github.com/sentry-kubernetes/charts/issues/110)) ([fe269f2](https://github.com/sentry-kubernetes/charts/commit/fe269f253d46f763e080c084b92fa4f8da296964))
* update Sentry & Snuba ([#80](https://github.com/sentry-kubernetes/charts/issues/80)) ([3f28140](https://github.com/sentry-kubernetes/charts/commit/3f281400fde3f06062a823ee06ea5474cfa261a3))
* update sentry to 20.7.1 ([#122](https://github.com/sentry-kubernetes/charts/issues/122)) ([e1014b8](https://github.com/sentry-kubernetes/charts/commit/e1014b8b49626818cf80329e445f48b2f68390a9))
* update sentry to february release ([#306](https://github.com/sentry-kubernetes/charts/issues/306)) ([e8d13dc](https://github.com/sentry-kubernetes/charts/commit/e8d13dc8afac5c878d85cf96f318a7fa316243be))
* update sentry&snuba ([#72](https://github.com/sentry-kubernetes/charts/issues/72)) ([3cae6b9](https://github.com/sentry-kubernetes/charts/commit/3cae6b9ae6f956ef9de8138265f3e18c95638bf5))
* update sentry&snuba images ([#53](https://github.com/sentry-kubernetes/charts/issues/53)) ([0427a1f](https://github.com/sentry-kubernetes/charts/commit/0427a1fc098c72a1b8b3a7af8a376247790f899b))
* updated clickhouse chart version ([6bdcea8](https://github.com/sentry-kubernetes/charts/commit/6bdcea8690d207b29e610f28363841cf0b0912c9))
* updated clickhouse to 1.4.0 ([17aa7ef](https://github.com/sentry-kubernetes/charts/commit/17aa7ef5a442986393ee473b9bcb439c15c866e9))
* updated kafka helm chart and supports kafka without zookeeper ([#888](https://github.com/sentry-kubernetes/charts/issues/888)) ([d8fab37](https://github.com/sentry-kubernetes/charts/commit/d8fab37ef108dea173e6e7412fd030bd977af754))
* updated tags to 20.8.0 ([#167](https://github.com/sentry-kubernetes/charts/issues/167)) ([91c7d41](https://github.com/sentry-kubernetes/charts/commit/91c7d41e14cb57d0951d7d88eafa721ccf430bb5))
* updating Sentry config.yaml to support actual yaml. ([#186](https://github.com/sentry-kubernetes/charts/issues/186)) ([945e4c0](https://github.com/sentry-kubernetes/charts/commit/945e4c0e44facbeae402fbb5f32a7ce05dd53dfe))
* upgrade kafka for more stability ([#246](https://github.com/sentry-kubernetes/charts/issues/246)) ([898fbcd](https://github.com/sentry-kubernetes/charts/commit/898fbcd72f13e5d139456d56d3a87f6a0f6e8833))
* upgrade sentry to 21.5.1 ([#389](https://github.com/sentry-kubernetes/charts/issues/389)) ([656d112](https://github.com/sentry-kubernetes/charts/commit/656d11265224a122a34eb5b043115af018f3c610))
* upgrade sentry to 21.6.1 ([#416](https://github.com/sentry-kubernetes/charts/issues/416)) ([2234ab9](https://github.com/sentry-kubernetes/charts/commit/2234ab90fdd66a76813d78c541b6331b79839d96))
* upgrade Sentry version to 21.3.1 ([#350](https://github.com/sentry-kubernetes/charts/issues/350)) ([13f4537](https://github.com/sentry-kubernetes/charts/commit/13f4537e4df3d67b4be82234309a580d2c4c9af4))


### Bug Fixes

* 419 using correct block indicator ([#420](https://github.com/sentry-kubernetes/charts/issues/420)) ([d4ff2b7](https://github.com/sentry-kubernetes/charts/commit/d4ff2b7476c91fb8f1120a5465203d6b8200eeca))
* add dbcheck job that ensures that clickhouse and kafka are up before proceeding ([#267](https://github.com/sentry-kubernetes/charts/issues/267)) ([8bdd076](https://github.com/sentry-kubernetes/charts/commit/8bdd076d1b45bfcfc393b68726f5b55b597a6756))
* add legacyApp field for slack ([#125](https://github.com/sentry-kubernetes/charts/issues/125)) ([dfe8a12](https://github.com/sentry-kubernetes/charts/commit/dfe8a1262989a44cbcdb0f79d11435dc13478740))
* add noStrictOffsetReset with ingestConsumer ([#1186](https://github.com/sentry-kubernetes/charts/issues/1186)) ([f4d2f74](https://github.com/sentry-kubernetes/charts/commit/f4d2f74431cb3d041b248729b75bd474ec6ef455))
* add performance-view in configmap-sentry.yaml ([#133](https://github.com/sentry-kubernetes/charts/issues/133)) ([72c41d2](https://github.com/sentry-kubernetes/charts/commit/72c41d2f70d70a66b9b8d1741eed098c19c03a0a))
* allow Redis only and fix Redis password use in BROKER_URL ([#24](https://github.com/sentry-kubernetes/charts/issues/24)) ([20c4ca1](https://github.com/sentry-kubernetes/charts/commit/20c4ca1baac88cefb8bcd7cf76de15013003807c))
* Apply appropriate batch apiVersion based on kubernetes version ([#700](https://github.com/sentry-kubernetes/charts/issues/700)) ([4128412](https://github.com/sentry-kubernetes/charts/commit/412841202e136f64266139132ebc96037a43d9ca))
* charts path ([2d7bcc9](https://github.com/sentry-kubernetes/charts/commit/2d7bcc98abbc367c62643bd0cb1d02bce52f893a))
* clickhouse database init "Bad get: has UInt64" because of '-' character in cluster name ([#204](https://github.com/sentry-kubernetes/charts/issues/204)) ([9f93287](https://github.com/sentry-kubernetes/charts/commit/9f932872ce44f8b4d3db5e7555cf3637be1a6d9d))
* dbCheck image can be pulled from custom repository ([#358](https://github.com/sentry-kubernetes/charts/issues/358)) ([#359](https://github.com/sentry-kubernetes/charts/issues/359)) ([6145595](https://github.com/sentry-kubernetes/charts/commit/61455956b1db50fc5b2af47a673d9759c86308db))
* distant clickhouse image ([5da5d86](https://github.com/sentry-kubernetes/charts/commit/5da5d866261db73d38437bdbbdf20057bd61b1df))
* django.security.csrf issue ([#155](https://github.com/sentry-kubernetes/charts/issues/155)) ([a680856](https://github.com/sentry-kubernetes/charts/commit/a680856c0208f4df626e05163f754442f59fca10))
* do not complete the user-create on error ([#58](https://github.com/sentry-kubernetes/charts/issues/58)) ([7b925fe](https://github.com/sentry-kubernetes/charts/commit/7b925feb8b0d28a2a47276ae666462d9107a4a9d))
* empty email values were crashing the pods ([#12](https://github.com/sentry-kubernetes/charts/issues/12)) ([5b6101f](https://github.com/sentry-kubernetes/charts/commit/5b6101fb0860ec0a8fff2dca86d1affc9b5d9656))
* erroneous formatting in relay configmap ([#203](https://github.com/sentry-kubernetes/charts/issues/203)) ([a42d41f](https://github.com/sentry-kubernetes/charts/commit/a42d41fe502c8a8e2394330cbf1c03eddc9d8d20)), closes [#202](https://github.com/sentry-kubernetes/charts/issues/202)
* external db ([#34](https://github.com/sentry-kubernetes/charts/issues/34)) ([87bfc2c](https://github.com/sentry-kubernetes/charts/commit/87bfc2c7d2e2713ac0e5e39d6a7fca89ef32ba9a))
* external postgres host ([#41](https://github.com/sentry-kubernetes/charts/issues/41)) ([bc6f5ab](https://github.com/sentry-kubernetes/charts/commit/bc6f5ab62ec1fb43d6b63254f6e6493344365acd))
* Fix wrong service account for ingest-profiles deployment ([#966](https://github.com/sentry-kubernetes/charts/issues/966)) ([cead469](https://github.com/sentry-kubernetes/charts/commit/cead469eb418e8ae110f60c173ab0bb9f74e4cc3))
* force UTC on clickhouse ([545052d](https://github.com/sentry-kubernetes/charts/commit/545052d90bb26559293e185f3436a671fa4ec2d4))
* gcs filestore ([#18](https://github.com/sentry-kubernetes/charts/issues/18)) ([5249630](https://github.com/sentry-kubernetes/charts/commit/524963031fb29932992d166cb3ae06237c6cc19e))
* github secret extra quotation mark([#415](https://github.com/sentry-kubernetes/charts/issues/415)) ([44cea73](https://github.com/sentry-kubernetes/charts/commit/44cea735054165be3e613dc142e9eb6f4136b032))
* Healthcheck for Relay backend was missing so when using .Values.ingress.regexPathStyle: gke will throw an error that template is missing ([#612](https://github.com/sentry-kubernetes/charts/issues/612)) ([9da34de](https://github.com/sentry-kubernetes/charts/commit/9da34de847716a74fd7e6f347c5bc723f7f00bc5))
* hide content-disposition header on /static for Safari ([#1051](https://github.com/sentry-kubernetes/charts/issues/1051)) ([a688d20](https://github.com/sentry-kubernetes/charts/commit/a688d20687f4c24cf9dd9dd4d54dc108b6dba2c7))
* hpa names to make them unique ([#102](https://github.com/sentry-kubernetes/charts/issues/102)) ([ab9126a](https://github.com/sentry-kubernetes/charts/commit/ab9126a20e74b816e8473e08e4dcd6eacca4224b))
* image pull policy ([#184](https://github.com/sentry-kubernetes/charts/issues/184)) ([0175798](https://github.com/sentry-kubernetes/charts/commit/0175798cf9982daef6f28771ce2dc6f4c688ff8d))
* imagePullPolicy ingest consumer ([b036dc1](https://github.com/sentry-kubernetes/charts/commit/b036dc1493d47e0888bd7d89e0ab8f5a26ff2a06))
* kafka env if disabled ([#43](https://github.com/sentry-kubernetes/charts/issues/43)) ([df96f9e](https://github.com/sentry-kubernetes/charts/commit/df96f9e8c84089e4c853651be4defad58ad40494))
* make ingress, rbac compatible with latest k8s versions ([#114](https://github.com/sentry-kubernetes/charts/issues/114)) ([8d2f319](https://github.com/sentry-kubernetes/charts/commit/8d2f3196fe797a301ba6ebb21b793f3030d70962))
* make the relay paths in the ingress compatible with traefik ([#274](https://github.com/sentry-kubernetes/charts/issues/274)) ([1707630](https://github.com/sentry-kubernetes/charts/commit/17076301717c4beafacf0febb64bb474b3897f6e))
* Make the snuba api liveness and readiness timeouts configurable ([#409](https://github.com/sentry-kubernetes/charts/issues/409)) ([9625fbe](https://github.com/sentry-kubernetes/charts/commit/9625fbe471aa751722e0daace15faa4d3a6e4fd9))
* **memcache:** do not set SERVER_MAX_VALUE_LENGTH with latest django versions ([#1131](https://github.com/sentry-kubernetes/charts/issues/1131)) ([1307658](https://github.com/sentry-kubernetes/charts/commit/1307658414ad84668b658c7411e952d487944589))
* Missing config for snuba migration ([#948](https://github.com/sentry-kubernetes/charts/issues/948)) ([becf6b5](https://github.com/sentry-kubernetes/charts/commit/becf6b5bcb7774e63c5c250ca0a99a4da289667f))
* missing profiling config ([#1038](https://github.com/sentry-kubernetes/charts/issues/1038)) ([5d21ac2](https://github.com/sentry-kubernetes/charts/commit/5d21ac2b358664d63560faf99d9a7108f4287c5a))
* new deployments should be sent as hook as well ([#229](https://github.com/sentry-kubernetes/charts/issues/229)) ([29cb2c9](https://github.com/sentry-kubernetes/charts/commit/29cb2c911620cbb179b34a7d6fc76c7e882e8c69))
* new dist tables ([#282](https://github.com/sentry-kubernetes/charts/issues/282)) ([6dd45b7](https://github.com/sentry-kubernetes/charts/commit/6dd45b7def24e291126eabfe883a033a9706dd87))
* nginx configmap name ([#185](https://github.com/sentry-kubernetes/charts/issues/185)) ([3e86a9a](https://github.com/sentry-kubernetes/charts/commit/3e86a9a3f09ce942782ab745009f9265f6d6574c))
* nginx static path not pass proxy ([#1060](https://github.com/sentry-kubernetes/charts/issues/1060)) ([ae07c35](https://github.com/sentry-kubernetes/charts/commit/ae07c35e642def515eacdaf0bd95d507fb3e8249))
* no events found ([6b85730](https://github.com/sentry-kubernetes/charts/commit/6b8573087a6363223335d8a5569e0811cb961858))
* pass postgresql password to user-create job ([#55](https://github.com/sentry-kubernetes/charts/issues/55)) ([4778949](https://github.com/sentry-kubernetes/charts/commit/4778949104db6192dfa09e83f43206337e754b34))
* pass postgress password to db-init ([#52](https://github.com/sentry-kubernetes/charts/issues/52)) ([73b5df2](https://github.com/sentry-kubernetes/charts/commit/73b5df227d1e996c24c8f301038d06f23e022862))
* persistent volume discrepancy ([#30](https://github.com/sentry-kubernetes/charts/issues/30)) ([3f70746](https://github.com/sentry-kubernetes/charts/commit/3f7074668300c0c80a866eda56982ef8c7886025))
* postgresql existing secret path ([#1004](https://github.com/sentry-kubernetes/charts/issues/1004)) ([68614e1](https://github.com/sentry-kubernetes/charts/commit/68614e1691e1d3a0f3ad6d80ca675e395fc439f7))
* rabbitmq connection ([#57](https://github.com/sentry-kubernetes/charts/issues/57)) ([0b18d52](https://github.com/sentry-kubernetes/charts/commit/0b18d52563e1938555395d994004d37b5b024102))
* rabbitmq to support new bitnami chart ([#320](https://github.com/sentry-kubernetes/charts/issues/320)) ([2936e90](https://github.com/sentry-kubernetes/charts/commit/2936e9075cc82c7aa2ad2fcdc2c11df8911d4e91))
* relay connection to sentry if port not 9000 ([#181](https://github.com/sentry-kubernetes/charts/issues/181)) ([44aaabf](https://github.com/sentry-kubernetes/charts/commit/44aaabf4b925a65f77ab2e2945f6ec82c36afe34))
* relay deployment ([#179](https://github.com/sentry-kubernetes/charts/issues/179)) ([d8e34f5](https://github.com/sentry-kubernetes/charts/commit/d8e34f569e01cb04e4c17d5a03313c95b2cbf642))
* replay session ([#1054](https://github.com/sentry-kubernetes/charts/issues/1054)) ([78c93e5](https://github.com/sentry-kubernetes/charts/commit/78c93e5996f7bc26ea4148e0aa8cb6c4b0b3aafb))
* reverted 20.7.2 (not working properly without relay) ([#128](https://github.com/sentry-kubernetes/charts/issues/128)) ([a61af24](https://github.com/sentry-kubernetes/charts/commit/a61af243e3adb85a2c89e6b0755dae250830a1d4))
* run Snuba in Distributed Dataset Mode ([#70](https://github.com/sentry-kubernetes/charts/issues/70)) ([7188166](https://github.com/sentry-kubernetes/charts/commit/7188166710aaaab6013c087c6091738731bb7ecf))
* sentry secret deleted ([#748](https://github.com/sentry-kubernetes/charts/issues/748)) ([7d90dda](https://github.com/sentry-kubernetes/charts/commit/7d90ddaa49c3b629049620d08b582bedbcd89b79))
* sentry version ([81bbe82](https://github.com/sentry-kubernetes/charts/commit/81bbe825b9bf52495b1eb6ded1d5d5dd1dfd04ff))
* sentry web options ([#406](https://github.com/sentry-kubernetes/charts/issues/406)) ([73d4213](https://github.com/sentry-kubernetes/charts/commit/73d4213d255746c1a05eb5b7bd23801489e416da))
* Set the right service account for ingest occurrences deployment ([#988](https://github.com/sentry-kubernetes/charts/issues/988)) ([a7d8390](https://github.com/sentry-kubernetes/charts/commit/a7d8390d46537dd904d2a9745358a894e304a6df))
* snuba - custom redis ([#23](https://github.com/sentry-kubernetes/charts/issues/23)) ([04ad7fa](https://github.com/sentry-kubernetes/charts/commit/04ad7fa1db3e52da3aeeb8751f17b9d7ff023e0a))
* snuba connection ([#13](https://github.com/sentry-kubernetes/charts/issues/13)) ([9bf1ffb](https://github.com/sentry-kubernetes/charts/commit/9bf1ffbddd4f8bc917d7602ad11b1c00443038b8))
* space in relay config ([4c281c4](https://github.com/sentry-kubernetes/charts/commit/4c281c400566d3d35e6dd50582cdbffe293c9390))
* special characters in email and password ([#165](https://github.com/sentry-kubernetes/charts/issues/165)) ([72df379](https://github.com/sentry-kubernetes/charts/commit/72df379355382d620fa3d28bf9f859d7938542cf))
* symbolicator usage ([#173](https://github.com/sentry-kubernetes/charts/issues/173)) ([4e457e3](https://github.com/sentry-kubernetes/charts/commit/4e457e3b228a41602a30ad5b4920bce3e673b474))
* templating error when disabling hooks ([#76](https://github.com/sentry-kubernetes/charts/issues/76)) ([f0a8e3f](https://github.com/sentry-kubernetes/charts/commit/f0a8e3f47a16895f0a1e11c6955cb5816454ebe2))
* the default clickhouse installation is distributed, only turn on single node when clickhouse is disabled ([#624](https://github.com/sentry-kubernetes/charts/issues/624)) ([d923eab](https://github.com/sentry-kubernetes/charts/commit/d923eab060512957e91217f9029cf5d3286fc2e6))
* turn off clickhouse backups to fix default installation ([#292](https://github.com/sentry-kubernetes/charts/issues/292)) ([45cc76d](https://github.com/sentry-kubernetes/charts/commit/45cc76da1c03ffe4c9e46f4be2c8d5b5c41f907d))
* update clickhouse chart to the latest version ([#103](https://github.com/sentry-kubernetes/charts/issues/103)) ([9b64422](https://github.com/sentry-kubernetes/charts/commit/9b6442221627531bf4ce2a60b559475f7d4070ba))
* updated gke BackendConfig with new values added on [#432](https://github.com/sentry-kubernetes/charts/issues/432) pull request ([#445](https://github.com/sentry-kubernetes/charts/issues/445)) ([cedbd69](https://github.com/sentry-kubernetes/charts/commit/cedbd69290c1b52c39f19da5088e34ebf276a6d3))
* worker should work with both redis & rabbitmq ([#48](https://github.com/sentry-kubernetes/charts/issues/48)) ([f4ab657](https://github.com/sentry-kubernetes/charts/commit/f4ab65782ac5603ae6df8df6d49220a9461f423a))
* **worker:** fix liveness probe changes ([#1139](https://github.com/sentry-kubernetes/charts/issues/1139)) ([1042c3d](https://github.com/sentry-kubernetes/charts/commit/1042c3dcc583ca09b69dd0ce23c1869ea2ac6ba2))
* zookeeper enabled per default ([ca18057](https://github.com/sentry-kubernetes/charts/commit/ca18057666d14159d968d9d0a10ee5a6b406f723))

## 22.0.2 (2024-04-12)

Automated releases
